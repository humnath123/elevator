using System.Data;

namespace Elevator_with_time
{
    public partial class Form1 : Form, IElevatorObserver
    {
        private readonly Elevator _elevatorA = new("Elevator A", Elevator.MinFloor);
        private readonly Elevator _elevatorB = new("Elevator B", Elevator.MinFloor);
        private Elevator[] _elevators;
        private LogRepository _repository;

        private DataTable _logTable;
        private DataView _logView;
        private string _lastEvent = "-";
        private bool _dbErrorShown;
        private bool _dbOffline;
        private bool _loadingLog;
        private bool _blink;                     // toggles every 250 ms (flashing alarm)
        private DateTime _lastBeep = DateTime.MinValue;

        private readonly System.Windows.Forms.Timer _clockTimer = new() { Interval = 250 };
        private static readonly TimeSpan AlarmDuration = TimeSpan.FromSeconds(6);

        public Form1()
        {
            InitializeComponent();
            DoubleBuffered = true;
            _elevators = new[] { _elevatorA, _elevatorB };

            // each elevator gets its OWN controller and its OWN panel: a control can only ever reach its own elevator
            // (the two panels are created by the designer in Form1.Designer.cs; here they get their elevator)
            _panelA.Bind(_elevatorA, new ElevatorController(_elevatorA), Ui.Blue, "A");
            _panelB.Bind(_elevatorB, new ElevatorController(_elevatorB), Ui.Violet, "B");
            BindDashboard();

            // the log takes about a fifth of the window, so the lifts above it always stay fully visible
            Resize += (s, e) => _logPanel.Height = Math.Clamp(ClientSize.Height / 5, 150, 260);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ApplyTheme();

            _repository = new LogRepository();
            _repository.ErrorOccurred += OnDatabaseError;
            _repository.EntriesWritten += () => LoadLog(false);   // keep the grid up to date
            _lblDbStatus.Text = "Database: " + LogRepository.Description;

            var logObserver = new LogObserver(_repository);        // database observer (rows carry the elevator name)
            foreach (Elevator el in _elevators)
            {
                el.Attach(this);                                   // GUI observer
                el.Attach(logObserver);
                el.PositionChanged += OnElevatorAnimated;          // delegates used for the animation
                el.DoorsChanged += OnElevatorAnimated;
            }

            _clockTimer.Tick += ClockTimer_Tick;
            _clockTimer.Start();
            UpdateClock();

            RefreshAll();
            foreach (Elevator el in _elevators) el.Notify("SYSTEM STARTED");
            LoadLog(false);
        }

        // ---------------------------------------------------------- top bar buttons

        private void btnLogs_Click(object sender, EventArgs e)
        {
            _hostLog.Visible = !_hostLog.Visible;
            _btnLogs.Lit = _hostLog.Visible;
            if (_hostLog.Visible) LoadLog(true);
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Database:  " + LogRepository.Description + "\n\n" +
                "Connection settings are read from dbsettings.json (next to the program).\n" +
                "Floors:  " + Elevator.FloorName(Elevator.MinFloor) + " to " + Elevator.FloorName(Elevator.MaxFloor) + "\n" +
                "Elevators:  Elevator A and Elevator B (independent)",
                "Settings", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnExit_Click(object sender, EventArgs e) => Close();

        // ---------------------------------------------------------- clock + alarm timeout

        private void ClockTimer_Tick(object sender, EventArgs e)
        {
            UpdateClock();
            _blink = !_blink;

            bool anyAlarm = false;
            foreach (Elevator el in _elevators)
            {
                if (!el.AlarmActive) continue;
                if (DateTime.Now - el.AlarmStarted > AlarmDuration)
                {
                    el.ClearAlarm("ALARM STOPPED AUTOMATICALLY");
                    continue;
                }
                anyAlarm = true;
            }

            if (anyAlarm)
            {
                if ((DateTime.Now - _lastBeep).TotalMilliseconds > 1200)       // repeating alarm tone
                {
                    _lastBeep = DateTime.Now;
                    try { System.Media.SystemSounds.Exclamation.Play(); } catch { /* no sound device: ignore */ }
                }
                RefreshAll();                                                   // flashing alarm indicators
            }
        }

        private void UpdateClock() => _lblClock.Text = DateTime.Now.ToString("ddd, dd MMM yyyy  HH:mm:ss");

        // ---------------------------------------------------------- animation (delegate, every timer tick)

        private void OnElevatorAnimated(Elevator elevator)
        {
            PanelOf(elevator)?.UpdateView(_blink);       // only the elevator that moved
            UpdateOverview();
        }

        // ---------------------------------------------------------- Observer callback

        public void OnElevatorEvent(Elevator elevator, string status)
        {
            _lastEvent = $"{DateTime.Now:HH:mm:ss}  {elevator.Name}: {status}";
            RefreshAll();
        }

        private ElevatorPanel PanelOf(Elevator elevator) =>
            elevator == _elevatorA ? _panelA : elevator == _elevatorB ? _panelB : null;

        // ---------------------------------------------------------- views

        private void RefreshAll()
        {
            _panelA.UpdateView(_blink);
            _panelB.UpdateView(_blink);
            UpdateOverview();
        }

        /// <summary>Overview cards and the system indicator in the top bar - all computed from the models.</summary>
        private void UpdateOverview()
        {
            _ovA.Text = Summary(_elevatorA);
            _ovB.Text = Summary(_elevatorB);

            int moving = _elevators.Count(x => x.IsMoving);
            _ovMoves.Text = $"{moving} of {_elevators.Length}";

            var emergency = _elevators.Where(x => x.IsEmergency).Select(x => x.Name).ToList();
            var alarms = _elevators.Where(x => x.AlarmActive).Select(x => x.Name).ToList();
            if (emergency.Count > 0)
            {
                _ovSafety.Text = "EMERGENCY: " + string.Join(", ", emergency);
                _ovSafety.ForeColor = Ui.Red;
                _pillSystem.Text = "EMERGENCY STOP ACTIVE";
                _pillSystem.PillColor = Ui.Red;
            }
            else if (alarms.Count > 0)
            {
                _ovSafety.Text = "ALARM: " + string.Join(", ", alarms);
                _ovSafety.ForeColor = Ui.Amber;
                _pillSystem.Text = "ALARM ACTIVE";
                _pillSystem.PillColor = Ui.Amber;
            }
            else if (_dbOffline)
            {
                _ovSafety.Text = "All clear";
                _ovSafety.ForeColor = Ui.Green;
                _pillSystem.Text = "ONLINE - DATABASE OFFLINE";
                _pillSystem.PillColor = Ui.Amber;
            }
            else
            {
                _ovSafety.Text = "All clear";
                _ovSafety.ForeColor = Ui.Green;
                _pillSystem.Text = "ONLINE - OPERATING NORMALLY";
                _pillSystem.PillColor = Ui.Green;
            }

            _ovLast.Text = _lastEvent;
        }

        private static string Summary(Elevator el)
        {
            string floor = "Floor " + Elevator.FloorName(el.CurrentFloor);
            string state = el.IsEmergency ? "Emergency"
                         : el.AlarmActive ? "Alarm"
                         : el.IsMoving ? (el.Direction > 0 ? "Moving up" : "Moving down")
                         : el.AllDoorsClosed ? "Idle" : "Doors " + el.DoorStateText.ToLowerInvariant();
            return floor + "  ·  " + state;
        }

        // ---------------------------------------------------------- theme (grid)

        private void ApplyTheme()
        {
            _dgvLog.EnableHeadersVisualStyles = false;
            _dgvLog.BackgroundColor = Ui.Surface;
            _dgvLog.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            _dgvLog.GridColor = Ui.Border;
            _dgvLog.RowTemplate.Height = 26;
            _dgvLog.ColumnHeadersHeight = 32;
            _dgvLog.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            _dgvLog.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            _dgvLog.DefaultCellStyle.Font = Ui.Face(9.5F);
            _dgvLog.DefaultCellStyle.BackColor = Ui.Surface;
            _dgvLog.DefaultCellStyle.ForeColor = Ui.Text;
            _dgvLog.DefaultCellStyle.SelectionBackColor = Color.FromArgb(48, 70, 120);
            _dgvLog.DefaultCellStyle.SelectionForeColor = Color.White;
            _dgvLog.DefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
            _dgvLog.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(26, 34, 54);
            _dgvLog.AlternatingRowsDefaultCellStyle.ForeColor = Ui.Text;
            _dgvLog.AlternatingRowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(48, 70, 120);
            _dgvLog.AlternatingRowsDefaultCellStyle.SelectionForeColor = Color.White;
            _dgvLog.ColumnHeadersDefaultCellStyle.Font = Ui.Face(9F, FontStyle.Bold);
            _dgvLog.ColumnHeadersDefaultCellStyle.BackColor = Ui.SurfaceAlt;
            _dgvLog.ColumnHeadersDefaultCellStyle.ForeColor = Ui.Muted;
            _dgvLog.ColumnHeadersDefaultCellStyle.SelectionBackColor = Ui.SurfaceAlt;
            _dgvLog.ColumnHeadersDefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
            _hostLog.Visible = true;    // log visible at the bottom (230 px) - both lifts stay fully visible above it
            _btnLogs.Lit = true;
        }

        // ---------------------------------------------------------- log (MySQL)

        private void OnDatabaseError(string message)
        {
            _dbOffline = true;
            _lblDbStatus.Text = "Database error: " + message.Replace("\r", " ").Replace("\n", " ");
            UpdateOverview();
            if (_dbErrorShown) return;      // show the full text once, so it can be read and copied
            _dbErrorShown = true;
            MessageBox.Show(message, "Database error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void btnLog_Click(object sender, EventArgs e) => LoadLog(true);

        private void LoadLog(bool userInitiated)
        {
            if (_loadingLog) return;
            _loadingLog = true;
            _repository.LoadLogsAsync(
                table =>
                {
                    _loadingLog = false;
                    _dbOffline = false;
                    _logTable = table;
                    _logView = new DataView(table);
                    _dgvLog.DataSource = _logView;
                    FormatLogGrid();
                    ApplyLogFilter();
                    _lblDbStatus.Text = $"Database: {LogRepository.Description}  -  {table.Rows.Count} newest records loaded.";
                    UpdateOverview();
                },
                error =>
                {
                    _loadingLog = false;
                    _dbOffline = true;
                    _lblDbStatus.Text = "Database error: " + error.Replace("\r", " ").Replace("\n", " ");
                    UpdateOverview();
                    if (userInitiated)
                        MessageBox.Show(error, "Database error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                });
        }

        private void FormatLogGrid()
        {
            if (_dgvLog.Columns.Count < 7) return;
            void Set(string name, float weight, int min, DataGridViewContentAlignment align)
            {
                DataGridViewColumn c = _dgvLog.Columns[name];
                c.FillWeight = weight;
                c.MinimumWidth = min;
                c.SortMode = DataGridViewColumnSortMode.NotSortable;     // the top row stays the newest event
                c.DefaultCellStyle.Alignment = align;
                c.HeaderCell.Style.Alignment = align;
            }
            Set("ID", 24, 46, DataGridViewContentAlignment.MiddleRight);
            Set("Date", 44, 84, DataGridViewContentAlignment.MiddleLeft);
            Set("Time", 36, 70, DataGridViewContentAlignment.MiddleLeft);
            Set("Elevator", 46, 90, DataGridViewContentAlignment.MiddleLeft);
            Set("Floor", 24, 48, DataGridViewContentAlignment.MiddleCenter);
            Set("Action", 150, 260, DataGridViewContentAlignment.MiddleLeft);
            Set("Status", 40, 76, DataGridViewContentAlignment.MiddleLeft);
        }

        /// <summary>Elevator / text / date filter applied to the loaded records.</summary>
        private void ApplyLogFilter()
        {
            if (_logView == null) return;

            var parts = new List<string>();
            if (_cmbElevator.SelectedIndex > 0)
                parts.Add($"[Elevator] = '{_cmbElevator.SelectedItem}'");

            string text = _txtSearch.Text.Trim();
            if (text.Length > 0)
                parts.Add($"[Action] LIKE '%{EscapeLike(text)}%'");

            if (_dtpDate.Checked)
                parts.Add($"[Date] = '{_dtpDate.Value:dd/MM/yyyy}'");

            try { _logView.RowFilter = string.Join(" AND ", parts); }
            catch (Exception) { _logView.RowFilter = ""; }

            int shown = _logView.Count, total = _logTable?.Rows.Count ?? 0;
            _lblCount.Text = $"{shown} of {total} records";
            _lblEmpty.Text = total == 0 ? "No log records yet." : "No records match the filters.";
            _lblEmpty.Visible = shown == 0;
        }

        private static string EscapeLike(string s)
        {
            var sb = new System.Text.StringBuilder();
            foreach (char c in s)
            {
                if (c == '\'') sb.Append("''");
                else if (c == '[' || c == ']' || c == '%' || c == '*') sb.Append('[').Append(c).Append(']');
                else sb.Append(c);
            }
            return sb.ToString();
        }

        /// <summary>Colours critical / warning events, marks the newest row and gives each elevator its accent.</summary>
        private void DgvLog_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0 || _dgvLog.Columns.Count < 7) return;
            DataGridViewRow row = _dgvLog.Rows[e.RowIndex];
            string status = Convert.ToString(row.Cells["Status"].Value);
            string column = _dgvLog.Columns[e.ColumnIndex].Name;

            if (column == "Status")
            {
                e.CellStyle.ForeColor = status == "Critical" ? Ui.Red : status == "Warning" ? Ui.Amber : Ui.Green;
                e.CellStyle.Font = Ui.Face(9F, FontStyle.Bold);
            }
            else if (column == "Elevator")
            {
                e.CellStyle.ForeColor = Convert.ToString(e.Value) == "Elevator B" ? Ui.Violet : Ui.Blue;
                e.CellStyle.Font = Ui.Face(9.5F, FontStyle.Bold);
            }
            else if (column == "Action" && status != "Info")
            {
                e.CellStyle.ForeColor = status == "Critical" ? Color.FromArgb(252, 165, 165) : Color.FromArgb(252, 211, 77);
            }

            if (e.RowIndex == 0)                                      // newest event
            {
                e.CellStyle.BackColor = Color.FromArgb(30, 52, 96);
                if (column == "Action") e.CellStyle.Font = Ui.Face(9.5F, FontStyle.Bold);
            }
        }

        private void btnClearLog_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Delete the whole elevator log?", "Clear Log",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            _repository.ClearAsync(
                () => LoadLog(true),
                error => MessageBox.Show(error, "Database error", MessageBoxButtons.OK, MessageBoxIcon.Warning));
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            _clockTimer.Stop();
            _clockTimer.Dispose();
            foreach (Elevator el in _elevators) el.Dispose();
            _repository?.Flush();
        }
    }
}
