using System.ComponentModel;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

namespace Elevator_with_time
{
    /// <summary>Drawing helpers: brushed-steel look.</summary>
    internal static class Steel
    {
        private static readonly Bitmap Grain = MakeGrain();

        private static Bitmap MakeGrain()
        {
            var bmp = new Bitmap(128, 128, PixelFormat.Format32bppArgb);
            var rng = new Random(7);
            using var g = Graphics.FromImage(bmp);
            for (int y = 0; y < 128; y++)
            {
                int a = rng.Next(0, 40);
                using var pen = new Pen(rng.Next(2) == 0 ? Color.FromArgb(a, 255, 255, 255) : Color.FromArgb(a, 0, 0, 0));
                g.DrawLine(pen, 0, y, 127, y);
            }
            return bmp;
        }

        public static void Fill(Graphics g, Rectangle r, GraphicsPath path = null)
        {
            if (r.Width < 2 || r.Height < 2) return;
            using var gradient = new LinearGradientBrush(r, Color.Silver, Color.Gray, LinearGradientMode.Horizontal);
            gradient.InterpolationColors = new ColorBlend
            {
                Colors = Theme.Current.Metal,
                Positions = new[] { 0f, 0.25f, 0.5f, 0.75f, 1f }
            };
            using var grain = new TextureBrush(Grain, WrapMode.Tile);
            if (path == null)
            {
                g.FillRectangle(gradient, r);
                g.FillRectangle(grain, r);
            }
            else
            {
                g.FillPath(gradient, path);
                g.FillPath(grain, path);
            }
        }

        public static GraphicsPath RoundRect(Rectangle r, int radius)
        {
            int d = radius * 2;
            var p = new GraphicsPath();
            p.AddArc(r.Left, r.Top, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Top, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }
    }

    /// <summary>Panel with a brushed-steel background (the elevator control panel).</summary>
    public class SteelPanel : Panel
    {
        public SteelPanel()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            Steel.Fill(g, ClientRectangle);

            // light sheen over the upper third
            int sheenH = Math.Max(2, Height / 3);
            using (var sheen = new LinearGradientBrush(new Rectangle(0, 0, Width, sheenH),
                       Color.FromArgb(70, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
                g.FillRectangle(sheen, 0, 0, Width, sheenH);

            // bevelled edge, amber trim and four screws
            using (var dark = new Pen(Color.FromArgb(140, 40, 42, 46), 2))
                g.DrawRectangle(dark, 1, 1, Width - 3, Height - 3);
            using (var accent = new Pen(Color.FromArgb(210, Theme.Current.Accent), 2))
                g.DrawRectangle(accent, 3, 3, Width - 7, Height - 7);
            foreach (var c in new[] { new Point(9, 9), new Point(Width - 10, 9), new Point(9, Height - 10), new Point(Width - 10, Height - 10) })
            {
                var screw = new Rectangle(c.X - 3, c.Y - 3, 7, 7);
                using (var sb = new LinearGradientBrush(screw, Color.FromArgb(235, 236, 240), Color.FromArgb(95, 98, 106), 45f))
                    g.FillEllipse(sb, screw);
                using (var sp = new Pen(Color.FromArgb(150, 40, 42, 46), 1))
                {
                    g.DrawEllipse(sp, screw);
                    g.DrawLine(sp, c.X - 2, c.Y + 2, c.X + 2, c.Y - 2);
                }
            }
        }
    }

    /// <summary>Glass sheen and recessed border for the dark digital displays.</summary>
    internal static class Glass
    {
        public static void Paint(Graphics g, Size size)
        {
            if (size.Width < 6 || size.Height < 6) return;
            var top = new Rectangle(0, 0, size.Width, Math.Max(2, size.Height / 2));
            using (var sheen = new LinearGradientBrush(top, Color.FromArgb(46, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
                g.FillRectangle(sheen, top);
            using (var outer = new Pen(Color.FromArgb(230, 8, 8, 10), 1))
                g.DrawRectangle(outer, 0, 0, size.Width - 1, size.Height - 1);
            using (var inner = new Pen(Color.FromArgb(40, 255, 255, 255), 1))
                g.DrawRectangle(inner, 1, 1, size.Width - 3, size.Height - 3);
        }
    }

    /// <summary>A label that looks like a dark glass display.</summary>
    public class DisplayLabel : Label
    {
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            base.OnPaintBackground(e);
            Glass.Paint(e.Graphics, Size);
        }
    }

    /// <summary>A panel that looks like a dark glass display.</summary>
    public class DisplayPanel : Panel
    {
        public DisplayPanel() { DoubleBuffered = true; }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            base.OnPaintBackground(e);
            Glass.Paint(e.Graphics, Size);
        }
    }

    /// <summary>Caption of a control-panel group, followed by an engraved line.</summary>
    public class SectionLabel : Label
    {
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Size text = TextRenderer.MeasureText(e.Graphics, Text, Font, new Size(int.MaxValue, int.MaxValue),
                                                 TextFormatFlags.NoPadding | TextFormatFlags.SingleLine);
            int x = text.Width + 14;
            int y = Height / 2;
            if (x >= Width - 4) return;
            using var dark = new Pen(Color.FromArgb(130, 60, 62, 68), 1);
            using var light = new Pen(Color.FromArgb(180, 255, 255, 255), 1);
            e.Graphics.DrawLine(dark, x, y, Width - 2, y);
            e.Graphics.DrawLine(light, x, y + 1, Width - 2, y + 1);
        }
    }

    /// <summary>White digital display, e.g. "★1", "▲G", "▼1".</summary>
    public class LedDisplay : Control
    {
        private string _floorText = "G";
        private int _direction;
        private string _caption = "";

        public LedDisplay()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Color.Black;
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string FloorText
        {
            get => _floorText;
            set { if (_floorText == value) return; _floorText = value; Invalidate(); }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int Direction
        {
            get => _direction;
            set { if (_direction == value) return; _direction = value; Invalidate(); }
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string Caption
        {
            get => _caption;
            set { _caption = value; Invalidate(); }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.Black);
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;

            // dark red band behind the digits (like a real LED window)
            Color led = Theme.Current.Led;
            using (var band = new SolidBrush(Color.FromArgb(led.R / 7, led.G / 7, led.B / 7)))
                g.FillRectangle(band, 0, Height * 3 / 10, Width, Height * 4 / 10);

            string symbol = _direction > 0 ? "▲" : _direction < 0 ? "▼" : "";
            string text = symbol + _floorText;

            float size = Height * 0.62f;
            Font font = new("Segoe UI Symbol", size, FontStyle.Bold, GraphicsUnit.Pixel);
            while (size > 6 && g.MeasureString(text, font).Width > Width - 6)
            {
                font.Dispose();
                size -= 2;
                font = new Font("Segoe UI Symbol", size, FontStyle.Bold, GraphicsUnit.Pixel);
            }

            var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
            var area = new RectangleF(0, 0, Width, Height);
            using (var glow = new SolidBrush(Color.FromArgb(60, led)))
                for (int dx = -2; dx <= 2; dx += 2)
                    for (int dy = -2; dy <= 2; dy += 2)
                        g.DrawString(text, font, glow, new RectangleF(dx, dy, Width, Height), format);
            using (var bright = new SolidBrush(led))
                g.DrawString(text, font, bright, area, format);
            font.Dispose();

            if (_caption.Length > 0)
            {
                using var small = new Font("Segoe UI", Math.Max(7f, Height * 0.17f), FontStyle.Bold, GraphicsUnit.Pixel);
                using var dim = new SolidBrush(Color.FromArgb(150, led));
                g.DrawString(_caption, small, dim, 4, 2);
            }
            using (var gloss = new LinearGradientBrush(new Rectangle(0, 0, Width, Math.Max(2, Height / 2)),
                       Color.FromArgb(40, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
                g.FillRectangle(gloss, 0, 0, Width, Math.Max(2, Height / 2));
            using var border = new Pen(Color.FromArgb(130, Theme.Current.Accent), 2);
            g.DrawRectangle(border, 1, 1, Width - 3, Height - 3);
        }
    }

    /// <summary>Drawing of the two sliding door leaves, shared by the cabin door and the landing doors.</summary>
    internal static class DoorArt
    {
        /// <summary>
        /// Two leaves inside an opening. open: 0 = closed .. 1 = fully open.
        /// The leaves slide sideways and disappear behind the frame (clipped to the opening).
        /// landing = true gives the graphite look of the building doors, false the bright silver of the cabin door.
        /// </summary>
        public static void Leaves(Graphics g, Rectangle opening, double open, bool landing)
        {
            if (opening.Width < 4 || opening.Height < 4) return;
            open = Math.Clamp(open, 0.0, 1.0);

            int half = opening.Width / 2;
            int shift = (int)Math.Round(half * open);

            GraphicsState saved = g.Save();
            g.SetClip(opening, CombineMode.Intersect);
            Leaf(g, new Rectangle(opening.Left - shift, opening.Top, half, opening.Height), landing);
            Leaf(g, new Rectangle(opening.Left + half + shift, opening.Top, opening.Width - half, opening.Height), landing);
            g.Restore(saved);
        }

        /// <summary>One brushed-steel door leaf with an embossed inset panel and a soft light streak.</summary>
        private static void Leaf(Graphics g, Rectangle r, bool landing)
        {
            if (r.Width < 2 || r.Height < 2) return;
            Steel.Fill(g, r);

            if (landing)
                using (var tint = new SolidBrush(Color.FromArgb(135, Theme.Current.Landing)))
                    g.FillRectangle(tint, r);

            int m = Math.Max(5, r.Height / 20);
            var inset = new Rectangle(r.Left + m, r.Top + m, r.Width - 2 * m, r.Height - 2 * m);
            if (inset.Width > 6 && inset.Height > 6)
            {
                using var dark = new Pen(Color.FromArgb(landing ? 150 : 90, 20, 22, 26), 1);
                using var light = new Pen(Color.FromArgb(landing ? 70 : 140, 255, 255, 255), 1);
                g.DrawRectangle(dark, inset);
                g.DrawRectangle(light, inset.Left + 1, inset.Top + 1, inset.Width - 1, inset.Height - 1);
            }

            if (landing)
            {
                // vertical ribs: another cue that these are the heavy building doors
                using var rib = new Pen(Color.FromArgb(55, 255, 255, 255), 1);
                int step = Math.Max(6, r.Width / 4);
                for (int x = r.Left + step; x < r.Right - 2; x += step)
                    g.DrawLine(rib, x, r.Top + m, x, r.Bottom - m);
            }

            using (var sheen = new LinearGradientBrush(r, Color.FromArgb(0, 255, 255, 255),
                       Color.FromArgb(landing ? 35 : 60, 255, 255, 255), LinearGradientMode.Horizontal))
            {
                sheen.SetBlendTriangularShape(0.5f);
                g.FillRectangle(sheen, r);
            }

            using var edge = new Pen(Color.FromArgb(landing ? 210 : 120, 15, 16, 18), 1);
            g.DrawRectangle(edge, r.Left, r.Top, r.Width - 1, r.Height - 1);
        }
    }

    /// <summary>Wall cladding: granite-look stone tiles in a running bond with bevelled grout joints.</summary>
    internal static class Cladding
    {
        private static Color Shade(Color c, int d) =>
            Color.FromArgb(c.A, Math.Clamp(c.R + d, 0, 255), Math.Clamp(c.G + d, 0, 255), Math.Clamp(c.B + d, 0, 255));

        public static void Paint(Graphics g, Rectangle area, int tileW, int tileH, int seed)
        {
            if (area.Width < 2 || area.Height < 2) return;
            tileW = Math.Max(20, tileW);
            tileH = Math.Max(20, tileH);

            ThemeData t = Theme.Current;
            var rng = new Random(seed);
            GraphicsState saved = g.Save();
            g.SetClip(area);
            g.SmoothingMode = SmoothingMode.None;

            // speckle brushes: dark grains and light grains (granite look)
            var grains = new List<SolidBrush>();
            for (int i = 0; i < 6; i++) grains.Add(new SolidBrush(Color.FromArgb(70 + i * 22, t.StoneDark)));
            for (int i = 0; i < 4; i++) grains.Add(new SolidBrush(Color.FromArgb(60 + i * 30, t.StoneLight)));

            using var jointDark = new Pen(Color.FromArgb(210, t.StoneJoint), 2);
            using var jointLight = new Pen(Color.FromArgb(120, t.StoneLight), 1);

            int row = 0;
            for (int y = area.Top; y < area.Bottom; y += tileH, row++)
            {
                int shift = row % 2 == 0 ? 0 : tileW / 2;       // running bond: every second row is offset
                for (int x = area.Left - shift; x < area.Right; x += tileW)
                {
                    var tile = new Rectangle(x, y, tileW, tileH);
                    Color baseColor = Shade(t.StoneBase, rng.Next(-14, 15));   // every tile has a slightly different tone

                    using (var fill = new LinearGradientBrush(tile, Shade(baseColor, 10), Shade(baseColor, -12), 70f))
                        g.FillRectangle(fill, tile);

                    int grainCount = tileW * tileH / 28;
                    for (int i = 0; i < grainCount; i++)
                    {
                        int size = rng.Next(10) == 0 ? 2 : 1;
                        g.FillRectangle(grains[rng.Next(grains.Count)],
                                        tile.Left + rng.Next(tileW), tile.Top + rng.Next(tileH), size, size);
                    }

                    // bevelled joints: light edge top/left, dark grout bottom/right
                    g.DrawLine(jointLight, tile.Left + 1, tile.Top + 1, tile.Right - 2, tile.Top + 1);
                    g.DrawLine(jointLight, tile.Left + 1, tile.Top + 1, tile.Left + 1, tile.Bottom - 2);
                    g.DrawLine(jointDark, tile.Left, tile.Bottom - 1, tile.Right, tile.Bottom - 1);
                    g.DrawLine(jointDark, tile.Right - 1, tile.Top, tile.Right - 1, tile.Bottom);
                }
            }

            foreach (SolidBrush b in grains) b.Dispose();
            g.Restore(saved);
        }
    }

    /// <summary>
    /// Cut-away picture of the building: stone-clad lobby walls, the hoistway with guide rails and ropes,
    /// the ELEVATOR CABIN (travelling up and down through the hoistway, with its own INNER door) and, on EVERY floor,
    /// a fixed LANDING DOOR assembly (steel frame, hall position indicator and two OUTER door leaves).
    ///
    /// Layers, back to front:  wall/hoistway  ->  ropes  ->  cabin  ->  landing door leaves  ->  landing door frames.
    /// The cabin moves with Elevator.Position; the landing doors never move. Their leaves open and close with the
    /// openness values of the Elevator model, so what is drawn is exactly what the safety logic says.
    /// </summary>
    public class ElevatorShaft : Panel
    {
        private Elevator _model;
        private int _hoverFloor;
        private Bitmap _back;                 // static picture behind the cabin
        private Bitmap _front;                // static picture in front of the cabin (landing door frames), transparent opening
        private Size _builtFor;
        private ThemeData _theme = Theme.Current;

        /// <summary>Accent colour of this shaft (blue for Elevator A, violet for Elevator B).</summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Color AccentColor
        {
            get => _theme.Accent;
            set { _theme = Theme.Current.WithAccent(value); _builtFor = Size.Empty; Invalidate(); }
        }

        /// <summary>Raised when an outside call button is clicked (argument: the elevator floor number).</summary>
        public event Action<int> CallRequested;

        public ElevatorShaft()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
        }

        /// <summary>The elevator that is drawn (position of the cabin, openness of every door, requests ...).</summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Elevator Model
        {
            get => _model;
            set { _model = value; Invalidate(); }
        }

        // ---------------------------------------------------------------- geometry (all proportional: DPI independent)

        private static int Floors => Elevator.MaxFloor - Elevator.MinFloor + 1;

        private int TopReserve => (int)Math.Round(Height * 0.065);                 // machine-room fascia with the legend
        private double Band => (Height - TopReserve) / (double)Floors;             // height of one storey
        private int Slab => Math.Max(8, (int)Math.Round(Band * 0.07));             // floor slab
        private int DoorH => (int)Math.Round(Band * 0.62);                         // height of a door opening
        private int HeaderH => (int)Math.Round(Band * 0.15);                       // landing frame header (hall indicator)
        private int CarTopH => (int)Math.Round(Band * 0.10);                       // cabin fascia above its door
        private int CarBase => Math.Max(5, (int)Math.Round(Band * 0.04));          // cabin floor below its door sill
        private int SillH => Math.Max(6, (int)Math.Round(Band * 0.04));            // landing sill / floor edge

        private int LeftWall => (int)Math.Round(Width * 0.12);
        private int RightWall => (int)Math.Round(Width * 0.20);
        private int Reveal => Math.Max(5, Width / 55);
        private int HoistW => Width - LeftWall - RightWall;
        private int CenterX => LeftWall + HoistW / 2;
        private int CarW => AsmW - 4;                                              // the cabin lives INSIDE the fixed landing frame (never wider than it)
        private int AsmW => (int)Math.Round(HoistW * 0.46);                        // landing door assembly (frame included)
        private int ShellW => (int)Math.Round(HoistW * 0.74);                      // fixed silver outer shell of a floor (wider than the frame)
        private int PostW => Math.Max(8, (int)Math.Round(Width * 0.04));
        private int OpenW => AsmW - 2 * PostW;
        private int AsmLeft => CenterX - AsmW / 2;
        private int OpenLeft => AsmLeft + PostW;

        /// <summary>Y coordinate of a floor level (the door sill); fractional positions give the cabin's travelling level.</summary>
        private int YFloor(double position) =>
            (int)Math.Round(Height - Slab - (position - Elevator.MinFloor) * Band);

        private Rectangle Opening(double position) => new Rectangle(OpenLeft, YFloor(position) - DoorH, OpenW, DoorH);

        private Rectangle Assembly(int floor) =>
            new Rectangle(AsmLeft, YFloor(floor) - DoorH - HeaderH, AsmW, DoorH + HeaderH + SillH);

        private Rectangle CarRect(double position) =>
            new Rectangle(CenterX - CarW / 2, YFloor(position) - DoorH - CarTopH, CarW, DoorH + CarTopH + CarBase);

        /// <summary>The fixed silver outer shell of ONE floor: bolted to the building, it never moves with the cabin.</summary>
        private Rectangle Shell(int floor) =>
            new Rectangle(CenterX - ShellW / 2, YFloor(floor) - DoorH - CarTopH, ShellW, DoorH + CarTopH + CarBase);

        private Rectangle HallWindow(int floor)
        {
            Rectangle a = Assembly(floor);
            int w = Math.Max(54, OpenW * 60 / 100);
            int h = Math.Max(18, HeaderH * 62 / 100);
            return new Rectangle(a.Left + (a.Width - w) / 2, a.Top + (HeaderH - h) / 2, w, h);
        }

        private Rectangle CallPlate(int floor)
        {
            int x0 = Width - RightWall + Reveal;
            int pw = Math.Max(30, Width * 12 / 100);
            int ph = Math.Max(60, DoorH * 60 / 100);
            int cy = YFloor(floor) - DoorH * 45 / 100;
            return new Rectangle(x0 + (Width - x0 - pw) / 2, cy - ph / 2, pw, ph);
        }

        private Rectangle CallButton(int floor)
        {
            Rectangle plate = CallPlate(floor);
            int d = plate.Width * 62 / 100;
            return new Rectangle(plate.Left + (plate.Width - d) / 2, plate.Top + plate.Height * 62 / 100 - d / 2, d, d);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _back?.Dispose();
                _front?.Dispose();
            }
            base.Dispose(disposing);
        }

        // ---------------------------------------------------------------- mouse: outside call buttons

        private int HitCallButton(Point p)
        {
            for (int floor = Elevator.MinFloor; floor <= Elevator.MaxFloor; floor++)
                if (Rectangle.Inflate(CallButton(floor), 4, 4).Contains(p)) return floor;
            return 0;
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            int hit = HitCallButton(e.Location);
            if (hit == _hoverFloor) return;
            _hoverFloor = hit;
            Cursor = hit != 0 ? Cursors.Hand : Cursors.Default;
            Invalidate();
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            if (_hoverFloor == 0) return;
            _hoverFloor = 0;
            Cursor = Cursors.Default;
            Invalidate();
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button != MouseButtons.Left) return;
            int hit = HitCallButton(e.Location);
            if (hit != 0) CallRequested?.Invoke(hit);
        }

        // ---------------------------------------------------------------- static layers (built once per size)

        private void BuildLayers()
        {
            _back?.Dispose();
            _front?.Dispose();
            _back = new Bitmap(Width, Height, PixelFormat.Format32bppPArgb);
            _front = new Bitmap(Width, Height, PixelFormat.Format32bppPArgb);
            _builtFor = Size;

            using (Graphics g = Graphics.FromImage(_back)) PaintBack(g);
            using (Graphics g = Graphics.FromImage(_front)) PaintFront(g);
        }

        private static void Plinth(Graphics g, int x0, int x1, int y, int h)
        {
            if (x1 - x0 < 2) return;
            var r = new Rectangle(x0, y, x1 - x0, h);
            using (var pb = new LinearGradientBrush(r, Color.FromArgb(92, 95, 102), Color.FromArgb(28, 29, 33), 90f))
                g.FillRectangle(pb, r);
            using (var hi = new Pen(Color.FromArgb(170, 235, 236, 240), 1))
                g.DrawLine(hi, x0, y, x1, y);
            using (var drop = new LinearGradientBrush(new Rectangle(x0, y + h, x1 - x0, 10),
                       Color.FromArgb(110, 0, 0, 0), Color.FromArgb(0, 0, 0, 0), 90f))
                g.FillRectangle(drop, x0, y + h, x1 - x0, 10);
        }

        /// <summary>Fixed silver outer shell with its "CAR" badge and lamp plate. The door opening stays dark: the moving cabin shows there.</summary>
        private void PaintShell(Graphics g, int floor)
        {
            Rectangle shell = Shell(floor);
            SmoothingMode oldMode = g.SmoothingMode;
            g.SmoothingMode = SmoothingMode.None;

            GraphicsState saved = g.Save();
            g.ExcludeClip(Rectangle.Inflate(Opening(floor), 3, 3));
            Steel.Fill(g, shell);
            using (var outer = new Pen(Color.FromArgb(80, 80, 85), 2))
                g.DrawRectangle(outer, shell.Left + 1, shell.Top + 1, shell.Width - 3, shell.Height - 3);
            g.Restore(saved);

            Rectangle badge = ShellBadge(floor), lamp = ShellLamp(floor);
            using (var bb = new LinearGradientBrush(badge, ControlPaint.Light(_theme.Accent, 0.35f), _theme.Accent, 90f))
                g.FillRectangle(bb, badge);
            using (var bp = new Pen(Color.FromArgb(180, 10, 14, 30), 1)) g.DrawRectangle(bp, badge);
            using (var bf = new Font("Segoe UI", 9f, FontStyle.Bold, GraphicsUnit.Pixel))
            using (var bt = new SolidBrush(Color.White))
            using (var bc = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                g.DrawString("CAR", bf, bt, badge, bc);
            using (var lb = new SolidBrush(Theme.Current.DisplayBack)) g.FillRectangle(lb, lamp);
            using (var lp = new Pen(Color.FromArgb(150, 20, 22, 26), 1)) g.DrawRectangle(lp, lamp);
            g.SmoothingMode = oldMode;
        }

        private Rectangle ShellBadge(int floor)
        {
            Rectangle shell = Shell(floor);
            int stripL = AsmLeft - shell.Left;
            int w = Math.Max(16, Math.Min(36, stripL - 6));
            return new Rectangle(shell.Left + (stripL - w) / 2, YFloor(floor) - DoorH * 55 / 100 - 7, w, 15);
        }

        private Rectangle ShellLamp(int floor)
        {
            Rectangle shell = Shell(floor);
            int stripR = shell.Right - (AsmLeft + AsmW);
            int w = Math.Max(16, Math.Min(36, stripR - 6));
            return new Rectangle(shell.Right - stripR + (stripR - w) / 2, YFloor(floor) - DoorH * 55 / 100 - 7, w, 15);
        }

        /// <summary>Live lamp on the shell: inner-door state while the cabin is levelled at this floor, otherwise this floor's landing door state.</summary>
        private void DrawShellLamp(Graphics g, Elevator el, int floor)
        {
            if (el == null) return;
            Rectangle plate = ShellLamp(floor);
            int d = Math.Min(10, plate.Height);
            bool here = el.IsAtFloor && el.CurrentFloor == floor;
            DrawLamp(g, new Rectangle(plate.Left + (plate.Width - d) / 2, plate.Top + (plate.Height - d) / 2, d, d),
                     StateColor(here ? el.Inner.State : el.GetLanding(floor).State));
        }

        /// <summary>Everything that is BEHIND the cabin: wall, hoistway, rails, floor slabs, plaques, call plates, legend.</summary>
        private void PaintBack(Graphics g)
        {
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            ThemeData t = _theme;

            // 1. stone cladding over the whole wall
            Cladding.Paint(g, new Rectangle(0, 0, Width, Height), Width * 27 / 100, Math.Max(30, Height / 12), 11);
            g.SmoothingMode = SmoothingMode.AntiAlias;

            int chL = LeftWall, chR = Width - RightWall;          // hoistway (the dark slot between the two wall columns)
            int rev = Reveal;

            // 2. soft shadow that the wall casts next to the hoistway
            int sh = Math.Max(10, Width / 22);
            using (var shadowL = new LinearGradientBrush(new Rectangle(chL - rev - sh, 0, sh, Height),
                       Color.FromArgb(0, 0, 0, 0), Color.FromArgb(100, 0, 0, 0), LinearGradientMode.Horizontal))
                g.FillRectangle(shadowL, chL - rev - sh, 0, sh, Height);
            using (var shadowR = new LinearGradientBrush(new Rectangle(chR + rev, 0, sh, Height),
                       Color.FromArgb(100, 0, 0, 0), Color.FromArgb(0, 0, 0, 0), LinearGradientMode.Horizontal))
                g.FillRectangle(shadowR, chR + rev, 0, sh, Height);

            // 3. hoistway: dark slot with cross ties, guide rails and steel reveal strips
            var hoist = new Rectangle(chL, 0, chR - chL, Height);
            using (var hb = new LinearGradientBrush(hoist, Color.FromArgb(10, 11, 13), Color.FromArgb(36, 38, 42), LinearGradientMode.Horizontal))
            {
                hb.SetBlendTriangularShape(0.5f);
                g.FillRectangle(hb, hoist);
            }
            using (var tie = new Pen(Color.FromArgb(55, 120, 124, 132), 2))
                for (int y = Height / 12; y < Height; y += Height / 7)
                    g.DrawLine(tie, chL + 4, y, chR - 4, y);

            int rail = Math.Max(7, Width / 42);
            Steel.Fill(g, new Rectangle(chL + 3, 0, rail, Height));
            Steel.Fill(g, new Rectangle(chR - 3 - rail, 0, rail, Height));
            Steel.Fill(g, new Rectangle(chL - rev, 0, rev, Height));
            Steel.Fill(g, new Rectangle(chR, 0, rev, Height));

            // 4. everything that belongs to ONE floor (fixed to the building): level line, slab, plaque, call plate
            using (var levelFont = new Font("Segoe UI", Math.Max(9f, Height * 0.016f), FontStyle.Bold, GraphicsUnit.Pixel))
            using (var levelBrush = new SolidBrush(Color.FromArgb(170, t.Accent)))
            using (var levelPen = new Pen(Color.FromArgb(110, t.Accent), 1) { DashStyle = DashStyle.Dash })
            {
                for (int floor = Elevator.MinFloor; floor <= Elevator.MaxFloor; floor++)
                {
                    int y = YFloor(floor);

                    // dashed floor level in the hoistway: the cabin floor must line up with it
                    g.DrawLine(levelPen, chL + rail + 4, y, chR - rail - 4, y);
                    g.DrawString("LEVEL " + Elevator.FloorName(floor), levelFont, levelBrush, chL + rail + 6, y - levelFont.Height - 2);

                    // polished floor in front of the ground-floor lift, slabs next to the hoistway on the other floors
                    if (floor == Elevator.MinFloor)
                    {
                        var floorRect = new Rectangle(0, y, Width, Height - y);
                        if (floorRect.Height > 2)
                            using (var fb = new LinearGradientBrush(floorRect, Color.FromArgb(78, 80, 88), Color.FromArgb(22, 23, 26), 90f))
                                g.FillRectangle(fb, floorRect);
                    }
                    else
                    {
                        Plinth(g, 0, chL - rev, y, Slab);
                        Plinth(g, chR + rev, Width, y, Slab);
                    }

                    PaintShell(g, floor);

                    // floor plaque on the left wall
                    int pq = Math.Max(22, (chL - rev) * 70 / 100);
                    var plaque = new Rectangle(((chL - rev) - pq) / 2, y - DoorH * 50 / 100 - pq / 2, pq, pq);
                    using (GraphicsPath pp = Steel.RoundRect(plaque, 5))
                    {
                        Steel.Fill(g, plaque, pp);
                        using var pen = new Pen(Color.FromArgb(120, 40, 42, 46), 1);
                        g.DrawPath(pen, pp);
                    }
                    using (var pf = new Font("Segoe UI", pq * 0.6f, FontStyle.Bold, GraphicsUnit.Pixel))
                    using (var pbrush = new SolidBrush(t.Ink))
                    using (var center = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                        g.DrawString(Elevator.FloorName(floor), pf, pbrush, plaque, center);

                    // call plate on the right wall (the round button itself is drawn live in OnPaint)
                    Rectangle plate = CallPlate(floor);
                    using (GraphicsPath cp = Steel.RoundRect(plate, 6))
                    {
                        using (var shade2 = new SolidBrush(Color.FromArgb(90, 0, 0, 0)))
                            g.FillRectangle(shade2, plate.Left + 2, plate.Top + 3, plate.Width, plate.Height);
                        Steel.Fill(g, plate, cp);
                        using var pen = new Pen(Color.FromArgb(150, 40, 42, 46), 1);
                        g.DrawPath(pen, cp);
                    }
                    using (var cf = new Font("Segoe UI", Math.Max(7f, plate.Height * 0.13f), FontStyle.Bold, GraphicsUnit.Pixel))
                    using (var cb = new SolidBrush(Color.FromArgb(200, t.Ink)))
                    using (var center = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                        g.DrawString("CALL", cf, cb, new Rectangle(plate.Left, plate.Top + plate.Height * 6 / 100, plate.Width, plate.Height * 26 / 100), center);
                    using (var screw = new SolidBrush(Color.FromArgb(150, 60, 62, 68)))
                    {
                        g.FillEllipse(screw, plate.Left + 4, plate.Top + plate.Height - 9, 4, 4);
                        g.FillEllipse(screw, plate.Right - 8, plate.Top + plate.Height - 9, 4, 4);
                    }
                }
            }

            // 5. machine-room fascia on top with the legend that explains the two kinds of doors
            int tr = TopReserve;
            var fascia = new Rectangle(0, 0, Width, tr);
            using (var fb = new LinearGradientBrush(fascia, Color.FromArgb(74, 76, 82), Color.FromArgb(24, 25, 28), 90f))
                g.FillRectangle(fb, fascia);
            using (var edgeDark = new Pen(Color.FromArgb(220, 10, 10, 12), 2))
                g.DrawLine(edgeDark, 0, tr, Width, tr);
            using (var edgeLight = new Pen(Color.FromArgb(90, 255, 255, 255), 1))
                g.DrawLine(edgeLight, 0, 1, Width, 1);

            float fpx = Math.Max(9f, tr * 0.30f);
            using (var lf = new Font("Segoe UI", fpx, FontStyle.Bold, GraphicsUnit.Pixel))
            using (var tb = new SolidBrush(t.TextLight))
            using (var fmt = new StringFormat { LineAlignment = StringAlignment.Center, FormatFlags = StringFormatFlags.NoWrap })
            {
                int chip = Math.Max(10, (int)fpx);
                int x = 12;
                string cabinText = "CABIN DOOR - MOVES";
                string landingText = "LANDING DOORS - FIXED";

                var chip1 = new Rectangle(x, (tr - chip) / 2, chip, chip);
                Steel.Fill(g, chip1);
                using (var trim = new Pen(t.Accent, 2)) g.DrawRectangle(trim, chip1);
                float w1 = g.MeasureString(cabinText, lf).Width;
                g.DrawString(cabinText, lf, tb, new RectangleF(x + chip + 6, 0, w1 + 4, tr), fmt);

                x += chip + 6 + (int)w1 + 20;
                var chip2 = new Rectangle(x, (tr - chip) / 2, chip, chip);
                Steel.Fill(g, chip2);
                using (var tint = new SolidBrush(Color.FromArgb(150, t.Landing))) g.FillRectangle(tint, chip2);
                using (var outline = new Pen(Color.FromArgb(200, 225, 227, 230), 1)) g.DrawRectangle(outline, chip2);
                g.DrawString(landingText, lf, tb, new RectangleF(x + chip + 6, 0, Width - x - chip - 8, tr), fmt);
            }
        }

        /// <summary>
        /// Everything that is IN FRONT of the cabin: the landing door frames of every floor (header, posts, sill),
        /// bolted to the building. The door opening itself is transparent so the cabin shows through when it is open.
        /// </summary>
        private void PaintFront(Graphics g)
        {
            g.Clear(Color.Transparent);
            ThemeData t = _theme;
            int chL = LeftWall, chR = Width - RightWall;
            int rail = Math.Max(7, Width / 42);

            for (int floor = Elevator.MinFloor; floor <= Elevator.MaxFloor; floor++)
            {
                Rectangle a = Assembly(floor);
                Rectangle open = Opening(floor);

                // shadow of the frame on whatever is behind it (never over the opening)
                GraphicsState saved = g.Save();
                g.ExcludeClip(open);
                using (var shade = new SolidBrush(Color.FromArgb(100, 0, 0, 0)))
                    g.FillRectangle(shade, a.Left - 4, a.Top - 3, a.Width + 8, a.Height + 8);
                g.Restore(saved);

                // floor edge: a steel strip across the hoistway at floor level; the cabin floor stops exactly on it
                var edgeStrip = new Rectangle(chL + rail + 3, open.Bottom, (chR - rail - 3) - (chL + rail + 3), SillH);
                Steel.Fill(g, edgeStrip);
                using (var tint = new SolidBrush(Color.FromArgb(120, t.Landing))) g.FillRectangle(tint, edgeStrip);
                using (var edgePen = new Pen(Color.FromArgb(170, 15, 16, 18), 1))
                    g.DrawRectangle(edgePen, edgeStrip.Left, edgeStrip.Top, edgeStrip.Width - 1, edgeStrip.Height - 1);

                // door frame: header with hall indicator window, two posts, sill
                var header = new Rectangle(a.Left, a.Top, a.Width, HeaderH);
                var postL = new Rectangle(a.Left, open.Top, PostW, open.Height);
                var postR = new Rectangle(a.Right - PostW, open.Top, PostW, open.Height);
                var sill = new Rectangle(a.Left, open.Bottom, a.Width, SillH);
                foreach (Rectangle part in new[] { header, postL, postR, sill })
                {
                    Steel.Fill(g, part);
                    using var tint = new SolidBrush(Color.FromArgb(125, t.Landing));
                    g.FillRectangle(tint, part);
                    using var edge = new Pen(Color.FromArgb(190, 15, 16, 18), 1);
                    g.DrawRectangle(edge, part.Left, part.Top, part.Width - 1, part.Height - 1);
                }

                // dark reveal around the opening
                using (var reveal = new Pen(Color.FromArgb(235, 10, 11, 13), 2))
                    g.DrawRectangle(reveal, open.Left - 1, open.Top - 1, open.Width + 1, open.Height + 1);

                // anchor bolts: the frame is fixed to the building
                g.SmoothingMode = SmoothingMode.AntiAlias;
                int bolt = Math.Max(5, PostW / 3);
                using (var boltBrush = new SolidBrush(Color.FromArgb(215, 205, 208, 214)))
                using (var boltPen = new Pen(Color.FromArgb(200, 20, 22, 26), 1))
                {
                    foreach (Rectangle post in new[] { postL, postR })
                        foreach (int by in new[] { open.Top + 10, open.Bottom - 10 - bolt })
                        {
                            var b = new Rectangle(post.Left + (post.Width - bolt) / 2, by, bolt, bolt);
                            g.FillEllipse(boltBrush, b);
                            g.DrawEllipse(boltPen, b);
                        }
                }
                g.SmoothingMode = SmoothingMode.None;

                // hall indicator window (the digits are drawn live in OnPaint)
                Rectangle hall = HallWindow(floor);
                using (var bezel = new Pen(Color.FromArgb(220, 24, 26, 30), 3))
                    g.DrawRectangle(bezel, Rectangle.Inflate(hall, 2, 2));
                using (var dark = new SolidBrush(t.DisplayBack))
                    g.FillRectangle(dark, hall);
            }
        }

        // ---------------------------------------------------------------- live drawing

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            if (Width < 60 || Height < 60) return;
            if (_back == null || _front == null || _builtFor != Size) BuildLayers();

            Elevator el = _model;
            double position = el != null ? el.Position : Elevator.MinFloor;
            bool emergency = el != null && el.IsEmergency;

            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAliasGridFit;
            g.DrawImageUnscaled(_back, 0, 0);

            // ropes, cabin (moves with the elevator position)
            Rectangle car = CarRect(position);
            DrawRopes(g, car);
            DrawCar(g, el, car, position);

            // landing door leaves of EVERY floor: fixed at their floor, opening only with the model's landing doors
            for (int floor = Elevator.MinFloor; floor <= Elevator.MaxFloor; floor++)
                DoorArt.Leaves(g, Opening(floor), el != null ? el.GetLandingOpenness(floor) : 0.0, true);

            // frames of the landing doors (in front of the cabin and of the sliding leaves)
            g.DrawImageUnscaled(_front, 0, 0);

            g.SmoothingMode = SmoothingMode.AntiAlias;
            for (int floor = Elevator.MinFloor; floor <= Elevator.MaxFloor; floor++)
            {
                DrawHallIndicator(g, el, floor);
                DrawShellLamp(g, el, floor);
                DrawCallButton(g, el, floor);
            }

            using var frame = new Pen(emergency ? Color.Red : Color.FromArgb(24, 25, 28), emergency ? 4 : 2);
            g.DrawRectangle(frame, 1, 1, Width - 3, Height - 3);
        }

        private void DrawRopes(Graphics g, Rectangle car)
        {
            int cx = CenterX;
            int dx = Math.Max(8, CarW / 12);
            using var rope = new Pen(Color.FromArgb(175, 177, 183), 3);
            g.DrawLine(rope, cx - dx, TopReserve, cx - dx, car.Top);
            g.DrawLine(rope, cx + dx, TopReserve, cx + dx, car.Top);
        }

        private static Color StateColor(DoorState state)
        {
            switch (state)
            {
                case DoorState.Open: return Theme.Current.Ok;
                case DoorState.Opening:
                case DoorState.Closing: return Color.FromArgb(245, 158, 11);
                case DoorState.Locked: return Theme.Current.Danger;
                default: return Theme.Current.Accent;            // closed, not locked (cabin levelled at this floor)
            }
        }

        private static void DrawLamp(Graphics g, Rectangle r, Color color)
        {
            using (var halo = new SolidBrush(Color.FromArgb(70, color)))
                g.FillEllipse(halo, Rectangle.Inflate(r, 3, 3));
            using (var body = new LinearGradientBrush(r, ControlPaint.Light(color, 0.6f), color, 90f))
                g.FillEllipse(body, r);
            using (var outline = new Pen(Color.FromArgb(200, 10, 10, 12), 1))
                g.DrawEllipse(outline, r);
        }

        /// <summary>The cabin: silver car body, direction display, its own INNER door (bright silver, amber trim).</summary>
        private void DrawCar(Graphics g, Elevator el, Rectangle car, double position)
        {
            ThemeData t = _theme;
            double open = el != null ? el.Inner.Openness : 0.0;
            bool emergency = el != null && el.IsEmergency;
            int direction = el != null ? el.Direction : 0;
            int y = YFloor(position);
            var opening = new Rectangle(OpenLeft, y - DoorH, OpenW, DoorH);

            g.SmoothingMode = SmoothingMode.None;
            Steel.Fill(g, car);                                            // silver car body

            // direction display in the cabin fascia (hidden behind the landing frame while the cabin is levelled)
            int dw = Math.Min(OpenW, CarW / 3);
            var disp = new Rectangle(CenterX - dw / 2, car.Top + 3, dw, Math.Max(8, CarTopH - 6));
            using (var back = new SolidBrush(t.DisplayBack)) g.FillRectangle(back, disp);
            string arrow = direction > 0 ? "\u2191" : direction < 0 ? "\u2193" : "\u2022";
            using (var arrowFont = new Font("Segoe UI Symbol", Math.Max(8f, disp.Height * 0.75f), FontStyle.Bold, GraphicsUnit.Pixel))
                TextRenderer.DrawText(g, arrow, arrowFont, disp, emergency ? Color.OrangeRed : t.Led,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine | TextFormatFlags.NoPadding);

            // recessed side panels of the car front
            Rectangle leftPanel = new Rectangle(car.Left + 5, opening.Top, Math.Max(2, opening.Left - 6 - (car.Left + 5)), opening.Height);
            Rectangle rightPanel = new Rectangle(opening.Right + 6, opening.Top, Math.Max(2, car.Right - 5 - (opening.Right + 6)), opening.Height);
            foreach (Rectangle p in new[] { leftPanel, rightPanel })
            {
                if (p.Width <= 6 || p.Height <= 6) continue;
                using var dark = new Pen(Color.FromArgb(90, 40, 42, 46), 1);
                using var light = new Pen(Color.FromArgb(140, 255, 255, 255), 1);
                g.DrawRectangle(dark, p);
                g.DrawRectangle(light, p.Left + 1, p.Top + 1, p.Width - 1, p.Height - 1);
            }

            // cabin interior (visible while the doors are open): lit back wall, mirror strip, handrail, floor
            Rectangle recess = Rectangle.Inflate(opening, 3, 3);
            using (var jamb = new SolidBrush(Color.FromArgb(150, 20, 22, 26))) g.FillRectangle(jamb, recess);

            Color top = emergency ? Color.FromArgb(230, 130, 120) : t.CabTop;
            Color bottom = emergency ? Color.FromArgb(100, 20, 20) : t.CabBottom;
            using (var cab = new LinearGradientBrush(opening, top, bottom, 90f))
                g.FillRectangle(cab, opening);
            int third = Math.Max(2, opening.Height / 3);
            using (var ceiling = new LinearGradientBrush(new Rectangle(opening.Left, opening.Top, opening.Width, third),
                       Color.FromArgb(130, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
                g.FillRectangle(ceiling, opening.Left, opening.Top, opening.Width, third);
            using (var mirror = new SolidBrush(Color.FromArgb(40, 255, 255, 255)))
                g.FillRectangle(mirror, opening.Left + opening.Width * 36 / 100, opening.Top, opening.Width * 28 / 100, opening.Height);
            int railY = opening.Top + opening.Height * 55 / 100;
            using (var rail = new Pen(Color.FromArgb(190, t.Accent), 3))
                g.DrawLine(rail, opening.Left, railY, opening.Right, railY);
            using (var railLight = new Pen(Color.FromArgb(140, 255, 255, 255), 1))
                g.DrawLine(railLight, opening.Left, railY - 2, opening.Right, railY - 2);
            using (var floorBrush = new SolidBrush(Color.FromArgb(130, 0, 0, 0)))
                g.FillRectangle(floorBrush, opening.Left, opening.Bottom - opening.Height / 9, opening.Width, opening.Height / 9);

            // the INNER door: two bright silver leaves that belong to the cabin and travel with it
            DoorArt.Leaves(g, opening, open, false);
            using (var trim = new Pen(Color.FromArgb(215, t.Accent), 2))
                g.DrawRectangle(trim, opening);

            // outline; amber glow around the cabin while its door is open, red in an emergency
            using (var outer = new Pen(Color.FromArgb(80, 80, 85), 2))
                g.DrawRectangle(outer, car.Left + 1, car.Top + 1, car.Width - 3, car.Height - 3);
            if (open > 0.02)
                using (var glow = new Pen(Color.FromArgb((int)(190 * open), t.Accent), 3))
                    g.DrawRectangle(glow, car.Left + 1, car.Top + 1, car.Width - 3, car.Height - 3);
            if (emergency)
                using (var red = new Pen(Color.FromArgb(220, Color.Red), 3))
                    g.DrawRectangle(red, car.Left + 1, car.Top + 1, car.Width - 3, car.Height - 3);
        }

        /// <summary>Hall position indicator, door lamp and floor letter in the header of a landing frame.</summary>
        private void DrawHallIndicator(Graphics g, Elevator el, int floor)
        {
            ThemeData t = _theme;
            Rectangle a = Assembly(floor);
            Rectangle r = HallWindow(floor);
            bool emergency = el != null && el.IsEmergency;
            int direction = el != null ? el.Direction : 0;
            string carFloor = Elevator.FloorName(el != null ? el.CurrentFloor : Elevator.MinFloor);

            Color led = emergency ? Color.FromArgb(255, 70, 60) : t.Led;
            string arrow = direction > 0 ? "\u25B2" : direction < 0 ? "\u25BC" : "";
            string text = emergency ? "STOP" : (arrow.Length > 0 ? arrow + " " : "") + carFloor;

            using (var font = new Font("Segoe UI Symbol", r.Height * 0.62f, FontStyle.Bold, GraphicsUnit.Pixel))
            using (var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
            {
                using (var glow = new SolidBrush(Color.FromArgb(55, led)))
                    g.DrawString(text, font, glow, new RectangleF(r.X + 1, r.Y + 1, r.Width, r.Height), format);
                using (var bright = new SolidBrush(led))
                    g.DrawString(text, font, bright, r, format);
            }
            using (var glass = new LinearGradientBrush(new Rectangle(r.X, r.Y, r.Width, Math.Max(2, r.Height / 2)),
                                                       Color.FromArgb(40, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
                g.FillRectangle(glass, r.X, r.Y, r.Width, Math.Max(2, r.Height / 2));

            // left of the indicator: state lamp of THIS floor's outer door
            int d = Math.Max(8, HeaderH * 28 / 100);
            int leftZone = r.Left - a.Left;
            if (el != null)
                DrawLamp(g, new Rectangle(a.Left + (leftZone - d) / 2, a.Top + (HeaderH - d) / 2, d, d), StateColor(el.GetLanding(floor).State));

            // right of the indicator: the name of this floor
            using (var nf = new Font("Segoe UI", Math.Max(9f, HeaderH * 0.48f), FontStyle.Bold, GraphicsUnit.Pixel))
            using (var nb = new SolidBrush(Color.FromArgb(235, t.Accent)))
            using (var nc = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
                g.DrawString(Elevator.FloorName(floor), nf, nb, new Rectangle(r.Right, a.Top, a.Right - r.Right, HeaderH), nc);
        }

        /// <summary>Round steel call button with an arrow; glows amber while the floor is requested.</summary>
        private void DrawCallButton(Graphics g, Elevator el, int floor)
        {
            ThemeData t = _theme;
            Rectangle b = CallButton(floor);
            bool lit = el != null && el.IsRequested(floor);
            bool hover = _hoverFloor == floor;

            if (lit)
                using (var halo = new SolidBrush(Color.FromArgb(80, t.Accent)))
                    g.FillEllipse(halo, Rectangle.Inflate(b, 5, 5));

            using (var ring = new LinearGradientBrush(b, Color.FromArgb(240, 241, 244), Color.FromArgb(105, 108, 116), 45f))
                g.FillEllipse(ring, b);
            Rectangle cap = Rectangle.Inflate(b, -3, -3);
            Color capTop = lit ? ControlPaint.Light(t.Accent, 0.4f) : hover ? Color.FromArgb(255, 245, 250) : Color.FromArgb(250, 215, 232);
            Color capBottom = lit ? t.Accent : Color.FromArgb(205, 130, 170);
            using (var capBrush = new LinearGradientBrush(cap, capTop, capBottom, 90f))
                g.FillEllipse(capBrush, cap);
            using (var outline = new Pen(Color.FromArgb(130, 40, 42, 46), 1))
                g.DrawEllipse(outline, b);

            // arrow: the lowest floor calls the lift UP, the highest DOWN, floors in between show both
            float cx = cap.Left + cap.Width / 2f, cy = cap.Top + cap.Height / 2f, s = cap.Width * 0.28f;
            bool up = floor < Elevator.MaxFloor;
            bool down = floor > Elevator.MinFloor;
            using (var arrowBrush = new SolidBrush(lit ? Color.White : t.Ink))
            {
                float off = up && down ? s * 0.9f : 0f;
                if (up)
                    g.FillPolygon(arrowBrush, new[] { new PointF(cx, cy - off - s * 0.8f), new PointF(cx - s * 0.8f, cy - off + s * 0.5f), new PointF(cx + s * 0.8f, cy - off + s * 0.5f) });
                if (down)
                    g.FillPolygon(arrowBrush, new[] { new PointF(cx, cy + off + s * 0.8f), new PointF(cx - s * 0.8f, cy + off - s * 0.5f), new PointF(cx + s * 0.8f, cy + off - s * 0.5f) });
            }
        }
    }

    public enum ButtonGlyph { Text, Up, Down, DoorOpen, DoorClose }

    /// <summary>Rounded steel push button; glows orange when "lit" (request pending).</summary>
    public class SteelButton : Button
    {
        private bool _hover, _down, _lit;

        public SteelButton()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            FlatStyle = FlatStyle.Flat;
            TabStop = false;
            Cursor = Cursors.Hand;
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ButtonGlyph Glyph { get; set; } = ButtonGlyph.Text;

        /// <summary>Optional colour wash over the steel (e.g. red emergency button).</summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Color Tint { get; set; } = Color.Empty;

        /// <summary>Optional text colour (default: dark ink).</summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Color TextColor { get; set; } = Color.Empty;

        protected override void OnEnabledChanged(EventArgs e) { Invalidate(); base.OnEnabledChanged(e); }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool Lit
        {
            get => _lit;
            set { if (_lit == value) return; _lit = value; Invalidate(); }
        }

        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; _down = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { _down = true; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { _down = false; Invalidate(); base.OnMouseUp(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            ButtonRenderer.DrawParentBackground(g, ClientRectangle, this);

            var body = new Rectangle(2, 2, Width - 5, Height - 5);
            using (GraphicsPath path = Steel.RoundRect(body, 8))
            {
                Steel.Fill(g, body, path);
                if (Tint != Color.Empty)
                    using (var wash = new SolidBrush(Color.FromArgb(185, Tint))) g.FillPath(wash, path);
                if (Enabled)
                {
                    GraphicsState state = g.Save();
                    g.SetClip(path, CombineMode.Intersect);
                    var topHalf = new Rectangle(body.X, body.Y, body.Width, Math.Max(2, body.Height / 2));
                    using (var gloss = new LinearGradientBrush(topHalf, Color.FromArgb(75, 255, 255, 255), Color.FromArgb(0, 255, 255, 255), 90f))
                        g.FillRectangle(gloss, topHalf);
                    g.Restore(state);
                }
                if (!Enabled)
                    using (var dim = new SolidBrush(Color.FromArgb(70, 70, 74, 80))) g.FillPath(dim, path);
                if (_down && Enabled)
                    using (var shade = new SolidBrush(Color.FromArgb(70, 0, 0, 0))) g.FillPath(shade, path);
                else if (_hover && Enabled)
                    using (var light = new SolidBrush(Color.FromArgb(40, 255, 255, 255))) g.FillPath(light, path);

                if (_lit)
                    using (var halo = new Pen(Color.FromArgb(90, Theme.Current.Accent), 6)) g.DrawPath(halo, path);
                Color borderColor = _lit ? Theme.Current.Accent : Color.FromArgb(85, 85, 90);
                using var pen = new Pen(borderColor, _lit ? 3 : 2);
                g.DrawPath(pen, path);
            }

            Color ink = !Enabled ? Color.FromArgb(78, 80, 86)
                      : TextColor != Color.Empty ? TextColor
                      : _lit ? ControlPaint.Dark(Theme.Current.Accent, 0.15f) : Theme.Current.Ink;
            if (Glyph == ButtonGlyph.Text)
            {
                TextRenderer.DrawText(g, Text, Font, ClientRectangle, ink,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine);
                return;
            }

            float cx = Width / 2f, cy = Height / 2f, s = Math.Min(Width, Height) * 0.26f, h = s * 0.9f;
            using var brush = new SolidBrush(ink);
            void Tri(float baseX, float tipX) =>
                g.FillPolygon(brush, new[] { new PointF(baseX, cy - h), new PointF(baseX, cy + h), new PointF(tipX, cy) });

            switch (Glyph)
            {
                case ButtonGlyph.Up:
                    g.FillPolygon(brush, new[] { new PointF(cx, cy - s), new PointF(cx - s, cy + s * 0.8f), new PointF(cx + s, cy + s * 0.8f) });
                    break;
                case ButtonGlyph.Down:
                    g.FillPolygon(brush, new[] { new PointF(cx, cy + s), new PointF(cx - s, cy - s * 0.8f), new PointF(cx + s, cy - s * 0.8f) });
                    break;
                case ButtonGlyph.DoorClose:      // ▶ ◀
                    Tri(cx - 2 * s, cx - 0.25f * s);
                    Tri(cx + 2 * s, cx + 0.25f * s);
                    break;
                case ButtonGlyph.DoorOpen:       // ◀ ▶
                    Tri(cx - 0.25f * s, cx - 2 * s);
                    Tri(cx + 0.25f * s, cx + 2 * s);
                    break;
            }
        }
    }
}