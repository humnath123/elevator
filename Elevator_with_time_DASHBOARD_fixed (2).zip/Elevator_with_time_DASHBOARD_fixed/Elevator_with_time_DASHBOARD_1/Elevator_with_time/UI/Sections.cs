using System.ComponentModel;

namespace Elevator_with_time
{
    // These three controls are the building blocks of the dashboard. Each one builds its own content in its
    // constructor, which is exactly what the Visual Studio designer needs: Form1.Designer.cs simply says
    // "new TopBarView()" and the designer runs the constructor, so the real layout is visible in Design view.

    // ====================================================================== A. top navigation bar

    public class TopBarView : Panel
    {
        private readonly StatusPill _pill;
        private readonly Label _clock;
        private readonly FlatButton _logs, _settings, _exit;

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public StatusPill Pill => _pill;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Label Clock => _clock;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public FlatButton LogsButton => _logs;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public FlatButton SettingsButton => _settings;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public FlatButton ExitButton => _exit;

        public TopBarView()
        {
            Dock = DockStyle.Top;
            Height = 60;
            BackColor = Ui.Surface;
            Paint += (s, e) =>
            {
                using var pen = new Pen(Ui.Border);
                e.Graphics.DrawLine(pen, 0, Height - 1, Width, Height - 1);
            };

            var t = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 8, RowCount = 1, BackColor = Ui.Surface, Padding = new Padding(14, 0, 14, 0) };
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 48));    // icon
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 250));   // name
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 300));   // system status
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));    // spacer
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200));   // clock
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 118));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 104));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 80));
            t.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            var icon = new AppIcon { Anchor = AnchorStyles.Left };
            var brand = new Label
            {
                Text = "Elevator Control System",
                Font = Ui.Face(13F, FontStyle.Bold),
                ForeColor = Ui.Text,
                BackColor = Ui.Surface,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                AutoEllipsis = true
            };
            _pill = new StatusPill { Dock = DockStyle.Fill, Margin = new Padding(0, 16, 0, 16), Text = "ONLINE - OPERATING NORMALLY" };
            _clock = new Label
            {
                Text = DateTime.Now.ToString("ddd, dd MMM yyyy  HH:mm:ss"),
                Font = Ui.Face(11F, FontStyle.Bold),
                ForeColor = Ui.Text,
                BackColor = Ui.Surface,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleRight,
                Padding = new Padding(0, 0, 14, 0)
            };
            _logs = TopButton("Activity Logs");
            _settings = TopButton("Settings");
            _exit = TopButton("Exit");
            _exit.Accent = Ui.Red;

            t.Controls.Add(icon, 0, 0);
            t.Controls.Add(brand, 1, 0);
            t.Controls.Add(_pill, 2, 0);
            t.Controls.Add(new Label { BackColor = Ui.Surface }, 3, 0);
            t.Controls.Add(_clock, 4, 0);
            t.Controls.Add(_logs, 5, 0);
            t.Controls.Add(_settings, 6, 0);
            t.Controls.Add(_exit, 7, 0);
            Controls.Add(t);
        }

        private static FlatButton TopButton(string text) => new()
        {
            Text = text,
            Dock = DockStyle.Fill,
            Margin = new Padding(0, 14, 8, 14),
            Font = Ui.Face(9.5F, FontStyle.Bold)
        };
    }

    // ====================================================================== shared system overview (5 cards)

    public class OverviewView : Panel
    {
        private readonly Label _a, _b, _moves, _safety, _last;

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Label ElevatorA => _a;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Label ElevatorB => _b;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Label Movements => _moves;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Label Safety => _safety;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Label LatestEvent => _last;

        public OverviewView()
        {
            Dock = DockStyle.Top;
            Height = 84;
            BackColor = Ui.Bg;
            Padding = new Padding(12, 10, 12, 8);

            var t = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 5, RowCount = 1, BackColor = Ui.Bg };
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18));
            t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            t.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            t.Controls.Add(Card("ELEVATOR A", out _a, Ui.Blue), 0, 0);
            t.Controls.Add(Card("ELEVATOR B", out _b, Ui.Violet), 1, 0);
            t.Controls.Add(Card("ACTIVE MOVEMENTS", out _moves, Ui.Cyan), 2, 0);
            t.Controls.Add(Card("SAFETY", out _safety, Ui.Green), 3, 0);
            t.Controls.Add(Card("LATEST EVENT", out _last, Ui.Muted), 4, 0);
            Controls.Add(t);
        }

        private static Control Card(string caption, out Label value, Color accent)
        {
            var card = new RoundedPanel { Dock = DockStyle.Fill, Margin = new Padding(0, 0, 8, 0), Padding = new Padding(14, 8, 10, 8) };
            var inner = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = Ui.Surface };
            inner.RowStyles.Add(new RowStyle(SizeType.Absolute, 20));
            inner.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            inner.Controls.Add(new Label
            {
                Text = caption, Font = Ui.Face(8.5F, FontStyle.Bold), ForeColor = accent, BackColor = Ui.Surface,
                Dock = DockStyle.Fill, TextAlign = ContentAlignment.BottomLeft
            }, 0, 0);
            value = new Label
            {
                Text = "-", Font = Ui.Face(11.5F, FontStyle.Bold), ForeColor = Ui.Text, BackColor = Ui.Surface,
                Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = true
            };
            inner.Controls.Add(value, 0, 1);
            card.Controls.Add(inner);
            return card;
        }
    }

    // ====================================================================== F. activity log

    public class LogView : Panel
    {
        private readonly ComboBox _cmbElevator;
        private readonly TextBox _txtSearch;
        private readonly DateTimePicker _dtpDate;
        private readonly Label _lblCount, _lblEmpty, _lblDbStatus;
        private readonly FlatButton _btnShowLog, _btnClearLog;
        private readonly DataGridView _dgvLog;

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public ComboBox ElevatorFilter => _cmbElevator;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TextBox SearchBox => _txtSearch;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DateTimePicker DateFilter => _dtpDate;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Label CountLabel => _lblCount;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Label EmptyLabel => _lblEmpty;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Label DbStatusLabel => _lblDbStatus;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public FlatButton ShowLogButton => _btnShowLog;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public FlatButton ClearLogButton => _btnClearLog;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DataGridView Grid => _dgvLog;

        public LogView()
        {
            Dock = DockStyle.Bottom;
            Height = 190;
            BackColor = Ui.Bg;
            Padding = new Padding(12, 0, 12, 12);

            var card = new RoundedPanel { Dock = DockStyle.Fill, Padding = new Padding(12, 8, 12, 8) };

            var t = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, BackColor = Ui.Surface };
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
            t.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            t.RowStyles.Add(new RowStyle(SizeType.Absolute, 22));

            // ---- toolbar: title, filters, count, Show Log / Clear Log
            var bar = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, BackColor = Ui.Surface, Margin = new Padding(0) };
            bar.Controls.Add(new Label
            {
                Text = "ACTIVITY LOG", Font = Ui.Face(10F, FontStyle.Bold), ForeColor = Ui.Text, BackColor = Ui.Surface,
                AutoSize = false, Size = new Size(120, 32), TextAlign = ContentAlignment.MiddleLeft
            });

            _cmbElevator = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Width = 140, Margin = new Padding(0, 5, 8, 0), FlatStyle = FlatStyle.Flat, BackColor = Ui.SurfaceAlt, ForeColor = Ui.Text };
            _cmbElevator.Items.AddRange(new object[] { "All elevators", "Elevator A", "Elevator B" });
            _cmbElevator.SelectedIndex = 0;

            _txtSearch = new TextBox { Width = 190, Margin = new Padding(0, 5, 8, 0), BorderStyle = BorderStyle.FixedSingle, BackColor = Ui.SurfaceAlt, ForeColor = Ui.Text, PlaceholderText = "Search action..." };

            _dtpDate = new DateTimePicker { Width = 130, Margin = new Padding(0, 5, 8, 0), Format = DateTimePickerFormat.Custom, CustomFormat = "dd/MM/yyyy", ShowCheckBox = true, Checked = false };

            _lblCount = new Label
            {
                Text = "", Font = Ui.Face(9F), ForeColor = Ui.Muted, BackColor = Ui.Surface,
                AutoSize = false, Size = new Size(170, 32), TextAlign = ContentAlignment.MiddleLeft, Margin = new Padding(4, 0, 0, 0)
            };

            _btnShowLog = new FlatButton { Text = "Show Log", Size = new Size(104, 32), Margin = new Padding(0, 2, 8, 0), Font = Ui.Face(9.5F, FontStyle.Bold) };
            _btnClearLog = new FlatButton { Text = "Clear Log", Size = new Size(104, 32), Margin = new Padding(0, 2, 0, 0), Font = Ui.Face(9.5F, FontStyle.Bold), Accent = Ui.Red };

            bar.Controls.AddRange(new Control[] { _cmbElevator, _txtSearch, _dtpDate, _btnShowLog, _btnClearLog, _lblCount });
            t.Controls.Add(bar, 0, 0);

            // ---- grid
            _dgvLog = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                ReadOnly = true,
                RowHeadersVisible = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                BorderStyle = BorderStyle.None,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                Margin = new Padding(0)
            };

            _lblEmpty = new Label
            {
                Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter, Font = Ui.Face(11F),
                ForeColor = Ui.Muted, BackColor = Ui.SurfaceAlt, Text = "No log records yet.", Visible = false
            };
            _dgvLog.Controls.Add(_lblEmpty);
            t.Controls.Add(_dgvLog, 0, 1);

            _lblDbStatus = new Label
            {
                Dock = DockStyle.Fill, Font = Ui.Face(8.5F), ForeColor = Ui.Muted, BackColor = Ui.Surface,
                TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = true, Text = "Ready."
            };
            t.Controls.Add(_lblDbStatus, 0, 2);

            card.Controls.Add(t);
            Controls.Add(card);
        }
    }
}
