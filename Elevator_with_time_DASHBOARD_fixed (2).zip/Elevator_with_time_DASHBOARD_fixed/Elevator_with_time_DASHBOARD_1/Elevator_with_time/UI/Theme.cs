namespace Elevator_with_time
{
    /// <summary>The colour scheme of the whole application (one theme only: dark industrial navy with blue / violet accents).</summary>
    public sealed class ThemeData
    {
        public string Name { get; init; }
        public Color[] Metal { get; init; }       // 5 gradient stops of the brushed steel
        public Color Led { get; init; }           // digits of the digital displays
        public Color Accent { get; set; }        // trims, lit buttons, door glow
        public Color CabTop { get; init; }        // cabin interior (top)
        public Color CabBottom { get; init; }     // cabin interior (bottom)
        public Color FormBack { get; init; }      // dark charcoal background
        public Color GridBack { get; init; }
        public Color DisplayBack { get; init; }   // background of the digital displays
        public Color TextLight { get; init; }     // text on the dark background
        public Color Ink { get; init; }           // text on silver metal
        public Color StoneBase { get; init; }     // wall cladding: granite tile colour
        public Color StoneDark { get; init; }     // wall cladding: dark speckles / shadow
        public Color StoneLight { get; init; }    // wall cladding: light speckles / highlight
        public Color StoneJoint { get; init; }    // wall cladding: grout lines between the tiles
        public Color Landing { get; init; }       // graphite tint of the stationary landing (floor) doors
        public Color Ok { get; init; }            // green lamps / open doors
        public Color Danger { get; init; }        // red lamps (emergency, locked)

        /// <summary>A copy of this theme with another accent colour (each elevator has its own).</summary>
        public ThemeData WithAccent(Color accent)
        {
            var copy = (ThemeData)MemberwiseClone();
            copy.Accent = accent;
            return copy;
        }
    }

    public static class Theme
    {
        public static ThemeData Current { get; } = new ThemeData
        {
            Name = "Dark Industrial",
            Metal = new[]
            {
                Color.FromArgb(176, 186, 202), Color.FromArgb(226, 232, 242), Color.FromArgb(150, 160, 178),
                Color.FromArgb(212, 219, 230), Color.FromArgb(138, 148, 166)
            },
            Led = Color.White,
            Accent = Color.FromArgb(59, 130, 246),
            CabTop = Color.FromArgb(220, 228, 240),
            CabBottom = Color.FromArgb(70, 82, 104),
            FormBack = Color.FromArgb(13, 17, 28),
            GridBack = Color.FromArgb(17, 22, 36),
            DisplayBack = Color.FromArgb(8, 11, 18),
            TextLight = Color.FromArgb(226, 232, 240),
            Ink = Color.FromArgb(20, 26, 40),
            StoneBase = Color.FromArgb(40, 50, 70),
            StoneDark = Color.FromArgb(14, 18, 30),
            StoneLight = Color.FromArgb(120, 140, 175),
            StoneJoint = Color.FromArgb(10, 13, 22),
            Landing = Color.FromArgb(24, 32, 50),
            Ok = Color.FromArgb(34, 197, 94),
            Danger = Color.FromArgb(239, 68, 68)
        };
    }
}

namespace Elevator_with_time
{
    /// <summary>Colours of the dashboard chrome (cards, text, status colours).</summary>
    public static class Ui
    {
        public static readonly Color Bg = Color.FromArgb(13, 17, 28);
        public static readonly Color Surface = Color.FromArgb(22, 29, 46);
        public static readonly Color SurfaceAlt = Color.FromArgb(29, 38, 59);
        public static readonly Color Border = Color.FromArgb(46, 58, 84);
        public static readonly Color Text = Color.FromArgb(241, 245, 249);
        public static readonly Color Muted = Color.FromArgb(148, 163, 184);
        public static readonly Color Blue = Color.FromArgb(59, 130, 246);
        public static readonly Color Cyan = Color.FromArgb(34, 211, 238);
        public static readonly Color Violet = Color.FromArgb(139, 92, 246);
        public static readonly Color Green = Color.FromArgb(34, 197, 94);
        public static readonly Color Amber = Color.FromArgb(245, 158, 11);
        public static readonly Color Red = Color.FromArgb(239, 68, 68);
        public static Font Face(float size, FontStyle style = FontStyle.Regular) => new Font("Segoe UI", size, style);
    }
}
