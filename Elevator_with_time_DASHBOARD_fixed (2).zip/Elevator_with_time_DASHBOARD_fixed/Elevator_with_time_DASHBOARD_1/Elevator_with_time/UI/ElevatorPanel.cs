using System.ComponentModel;

namespace Elevator_with_time
{
    /// <summary>
    /// A complete, independent control panel for ONE elevator: header, shaft drawing, status display,
    /// floor / movement / door / safety controls. It only talks to its own Elevator and ElevatorController,
    /// so a click here can never operate the other elevator.
    /// </summary>
    public class ElevatorPanel : RoundedPanel
    {
        private Elevator _elevator;
        private ElevatorController _controller;
        private Color _accent = Ui.Blue;
        private readonly Label _badge = new();

        private readonly Label _title = new();
        private readonly StatusPill _statePill = new();
        private readonly StatusPill _interlockPill = new();
        private readonly ElevatorShaft _shaft = new();

        private readonly Label _vFloor = new(), _vDest = new(), _vDir = new(), _vDoor = new();
        private readonly Label _vInner = new(), _vOuter = new(), _vStatus = new(), _vQueue = new();
        private readonly MoveProgress _progress = new();
        private readonly Label _hint = new();

        private readonly List<FlatButton> _floorButtons = new();
        private readonly FlatButton _btnUp = new(), _btnDown = new(), _btnOpen = new(), _btnClose = new();
        private readonly FlatButton _btnEmergency = new(), _btnAlarm = new(), _btnReset = new();

        private double _moveFrom;          // cabin position when the current trip started (for the progress bar)

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Elevator Model => _elevator;

        /// <summary>
        /// Parameterless constructor: this is what the Visual Studio designer calls, so the full panel is drawn in
        /// Design view. At run time Form1 calls <see cref="Bind"/> to connect the panel to its elevator.
        /// </summary>
        public ElevatorPanel()
        {
            Padding = new Padding(14);
            MinimumSize = new Size(600, 470);
            BorderColor = Color.FromArgb(120, _accent);

            BuildLayout("A");
            _shaft.AccentColor = _accent;
            _shaft.CallRequested += floor => Run(() => _elevator?.RequestFloor(floor));   // wall call buttons of THIS shaft
        }

        public ElevatorPanel(Elevator elevator, ElevatorController controller, Color accent, string badge) : this()
        {
            Bind(elevator, controller, accent, badge);
        }

        /// <summary>Connects this panel to ONE elevator + its own controller and applies that elevator's accent colour.</summary>
        public void Bind(Elevator elevator, ElevatorController controller, Color accent, string badge)
        {
            _elevator = elevator;
            _controller = controller;
            _accent = accent;
            _moveFrom = elevator.Position;
            BorderColor = Color.FromArgb(120, accent);

            _badge.Text = badge;
            _badge.BackColor = accent;
            _title.Text = elevator.Name.ToUpperInvariant();
            _progress.Accent = accent;
            foreach (FlatButton b in _floorButtons) b.Accent = accent;
            _btnUp.Accent = _btnDown.Accent = _btnOpen.Accent = _btnClose.Accent = accent;
            _shaft.Model = elevator;
            _shaft.AccentColor = accent;
        }

        // ------------------------------------------------------------------ layout (all docked: resizes with the window)

        private static Label MakeLabel(string text, Font font, Color color, ContentAlignment align = ContentAlignment.MiddleLeft) => new()
        {
            Text = text,
            Font = font,
            ForeColor = color,
            BackColor = Ui.Surface,
            TextAlign = align,
            Dock = DockStyle.Fill,
            AutoEllipsis = true,
            Margin = new Padding(0)
        };

        private void BuildLayout(string badge)
        {
            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = Ui.Surface };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            Controls.Add(root);

            // ---- header: accent badge + name | interlock pill | state pill
            var header = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 1, BackColor = Ui.Surface, Margin = new Padding(0) };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 190));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
            var badgeLabel = _badge;
            badgeLabel.Text = badge;
            badgeLabel.Font = Ui.Face(14F, FontStyle.Bold);
            badgeLabel.ForeColor = Color.White;
            badgeLabel.TextAlign = ContentAlignment.MiddleCenter;
            badgeLabel.AutoEllipsis = true;
            badgeLabel.BackColor = _accent;
            badgeLabel.Dock = DockStyle.None;
            badgeLabel.Size = new Size(34, 34);
            badgeLabel.Margin = new Padding(0, 2, 0, 2);
            _title.Text = _elevator != null ? _elevator.Name.ToUpperInvariant() : "ELEVATOR";
            _title.Font = Ui.Face(14F, FontStyle.Bold);
            _title.ForeColor = Ui.Text;
            _title.BackColor = Ui.Surface;
            _title.Dock = DockStyle.Fill;
            _title.TextAlign = ContentAlignment.MiddleLeft;
            _title.Padding = new Padding(8, 0, 0, 0);
            _interlockPill.Dock = DockStyle.Fill;
            _interlockPill.Margin = new Padding(0, 6, 8, 6);
            _statePill.Dock = DockStyle.Fill;
            _statePill.Margin = new Padding(0, 6, 0, 6);
            header.Controls.Add(badgeLabel, 0, 0);
            header.Controls.Add(_title, 1, 0);
            header.Controls.Add(_interlockPill, 2, 0);
            header.Controls.Add(_statePill, 3, 0);
            root.Controls.Add(header, 0, 0);

            // ---- body: shaft (left) | controls (right)
            var body = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 1, BackColor = Ui.Surface, Margin = new Padding(0) };
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55));
            _shaft.Dock = DockStyle.Fill;
            _shaft.Margin = new Padding(0, 6, 12, 0);
            body.Controls.Add(_shaft, 0, 0);
            body.Controls.Add(BuildControlsColumn(), 1, 0);
            root.Controls.Add(body, 0, 1);
        }

        private Control BuildControlsColumn()
        {
            var col = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, BackColor = Ui.Surface, Margin = new Padding(0) };
            // info card | progress | hint | FLOOR | row | MOVEMENT | row | DOOR | row | SAFETY | row
            float[] heights = { 0, 12, 26, 20, 0, 20, 0, 20, 0, 20, 0 };
            bool[] percent = { true, false, false, false, true, false, true, false, true, false, true };
            float[] weights = { 34, 0, 0, 0, 14, 0, 14, 0, 14, 0, 14 };
            col.RowCount = heights.Length;
            for (int i = 0; i < heights.Length; i++)
                col.RowStyles.Add(percent[i] ? new RowStyle(SizeType.Percent, weights[i]) : new RowStyle(SizeType.Absolute, heights[i]));

            col.Controls.Add(BuildInfoCard(), 0, 0);

            _progress.Accent = _accent;
            _progress.Dock = DockStyle.Fill;
            _progress.Margin = new Padding(0, 4, 0, 0);
            col.Controls.Add(_progress, 0, 1);

            _hint.Font = Ui.Face(9F, FontStyle.Regular);
            _hint.ForeColor = Ui.Muted;
            _hint.BackColor = Ui.Surface;
            _hint.Dock = DockStyle.Fill;
            _hint.TextAlign = ContentAlignment.MiddleLeft;
            _hint.AutoEllipsis = true;
            col.Controls.Add(_hint, 0, 2);

            // FLOOR: one button per floor (Ground, Floor 1, ...), the floor number is kept in the button's Tag
            col.Controls.Add(Caption("FLOOR"), 0, 3);
            var floors = Row(Elevator.MaxFloor - Elevator.MinFloor + 1);
            for (int f = Elevator.MinFloor; f <= Elevator.MaxFloor; f++)
            {
                string n = Elevator.FloorName(f);
                var b = MakeButton(f == Elevator.MinFloor ? "Ground" : "Floor " + n);
                b.Tag = f;
                b.Click += (s, e) => { if (s is FlatButton fb && fb.Tag is int floor) Run(() => _elevator.RequestFloor(floor)); };
                _floorButtons.Add(b);
                floors.Controls.Add(b, f - Elevator.MinFloor, 0);
            }
            col.Controls.Add(floors, 0, 4);

            col.Controls.Add(Caption("MOVEMENT"), 0, 5);
            var move = Row(2);
            _btnUp.Text = "▲  Move Up";
            _btnDown.Text = "▼  Move Down";
            Style(_btnUp); Style(_btnDown);
            _btnUp.Click += (s, e) => Run(_controller.GoUp);
            _btnDown.Click += (s, e) => Run(_controller.GoDown);
            move.Controls.Add(_btnUp, 0, 0);
            move.Controls.Add(_btnDown, 1, 0);
            col.Controls.Add(move, 0, 6);

            col.Controls.Add(Caption("DOOR"), 0, 7);
            var doors = Row(2);
            _btnOpen.Text = "Open Door";
            _btnClose.Text = "Close Door";
            Style(_btnOpen); Style(_btnClose);
            _btnOpen.Click += (s, e) => Run(_elevator.OpenDoors);
            _btnClose.Click += (s, e) => Run(_elevator.CloseDoors);
            doors.Controls.Add(_btnOpen, 0, 0);
            doors.Controls.Add(_btnClose, 1, 0);
            col.Controls.Add(doors, 0, 8);

            col.Controls.Add(Caption("SAFETY"), 0, 9);
            var safety = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 1, BackColor = Ui.Surface, Margin = new Padding(0) };
            safety.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 44));
            safety.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28));
            safety.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28));
            _btnEmergency.Text = "EMERGENCY STOP";
            _btnEmergency.Solid = Ui.Red;
            _btnAlarm.Text = "Alarm";
            _btnReset.Text = "Reset";
            Style(_btnEmergency); Style(_btnAlarm); Style(_btnReset);
            _btnAlarm.Accent = Ui.Amber;
            _btnReset.Accent = Ui.Green;
            _btnEmergency.Click += (s, e) => Run(_elevator.EmergencyStop);
            _btnAlarm.Click += (s, e) => Run(_elevator.RaiseAlarm);
            _btnReset.Click += (s, e) => Run(_elevator.Reset);
            safety.Controls.Add(_btnEmergency, 0, 0);
            safety.Controls.Add(_btnAlarm, 1, 0);
            safety.Controls.Add(_btnReset, 2, 0);
            col.Controls.Add(safety, 0, 10);
            return col;
        }

        private Control BuildInfoCard()
        {
            var card = new RoundedPanel { Dock = DockStyle.Fill, FillColor = Ui.SurfaceAlt, BorderColor = Ui.Border, Padding = new Padding(12, 8, 12, 8), Margin = new Padding(0) };
            var grid = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 4, BackColor = Ui.SurfaceAlt };
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 22));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 22));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28));
            for (int r = 0; r < 4; r++) grid.RowStyles.Add(new RowStyle(SizeType.Percent, 25));

            void Add(string key, Label value, int row, int col)
            {
                var k = MakeLabel(key, Ui.Face(8.5F), Ui.Muted);
                k.BackColor = Ui.SurfaceAlt;
                value.Font = Ui.Face(10F, FontStyle.Bold);
                value.ForeColor = Ui.Text;
                value.BackColor = Ui.SurfaceAlt;
                value.Dock = DockStyle.Fill;
                value.TextAlign = ContentAlignment.MiddleLeft;
                value.AutoEllipsis = true;
                value.Margin = new Padding(0);
                grid.Controls.Add(k, col * 2, row);
                grid.Controls.Add(value, col * 2 + 1, row);
            }
            Add("Floor", _vFloor, 0, 0);       Add("Destination", _vDest, 0, 1);
            Add("Direction", _vDir, 1, 0);     Add("Door state", _vDoor, 1, 1);
            Add("Inner door", _vInner, 2, 0);  Add("Landing door", _vOuter, 2, 1);
            Add("Status", _vStatus, 3, 0);     Add("Requests", _vQueue, 3, 1);
            card.Controls.Add(grid);
            return card;
        }

        private static Label Caption(string text)
        {
            var l = MakeLabel(text, Ui.Face(8.5F, FontStyle.Bold), Ui.Muted);
            l.Padding = new Padding(2, 4, 0, 0);
            l.TextAlign = ContentAlignment.BottomLeft;
            return l;
        }

        private static TableLayoutPanel Row(int columns)
        {
            var t = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = columns, RowCount = 1, BackColor = Ui.Surface, Margin = new Padding(0) };
            for (int i = 0; i < columns; i++) t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / columns));
            return t;
        }

        private FlatButton MakeButton(string text)
        {
            var b = new FlatButton { Text = text };
            Style(b);
            return b;
        }

        private void Style(FlatButton b)
        {
            b.Dock = DockStyle.Fill;
            b.Margin = new Padding(0, 2, 6, 2);
            b.Accent = _accent;
            b.MinimumSize = new Size(40, 30);
        }

        private static void Run(Action action)
        {
            try { action(); }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Elevator", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // ------------------------------------------------------------------ view update (reads the model only)

        /// <summary>Redraws everything from the elevator model; called on every animation tick and event.</summary>
        public void UpdateView(bool blink)
        {
            Elevator el = _elevator;
            bool emergency = el.IsEmergency;
            bool moving = el.IsMoving;
            bool alarm = el.AlarmActive;
            bool doorsClosed = el.AllDoorsClosed;
            string floor = Elevator.FloorName(el.CurrentFloor);
            int destination = el.DestinationFloor;
            string destinationText = destination == 0 ? "-" : Elevator.FloorName(destination);

            _shaft.Invalidate();

            string direction = emergency ? "STOPPED"
                             : el.Direction > 0 ? "Moving Up ▲"
                             : el.Direction < 0 ? "Moving Down ▼" : "Idle";
            string status = emergency ? "EMERGENCY STOP" : alarm ? "ALARM ACTIVE" : el.StatusText;

            _vFloor.Text = floor;
            _vDest.Text = destinationText;
            _vDir.Text = direction;
            _vDoor.Text = el.DoorStateText;
            _vInner.Text = el.Inner.Text;
            _vOuter.Text = el.OuterDoorText;
            _vStatus.Text = status;
            _vQueue.Text = el.Pending.Count == 0 ? "-" : string.Join(", ", el.Pending.Select(Elevator.FloorName));

            _vInner.ForeColor = DoorColor(el.Inner);
            _vOuter.ForeColor = DoorColor(el.ActiveOuterDoor);
            _vDir.ForeColor = moving ? _accent : Ui.Text;
            _vStatus.ForeColor = emergency ? Ui.Red : alarm ? Ui.Amber : Ui.Text;

            // ---- pills
            if (emergency) { _statePill.Text = "EMERGENCY"; _statePill.PillColor = Ui.Red; }
            else if (alarm) { _statePill.Text = "ALARM"; _statePill.PillColor = blink ? Ui.Amber : Ui.Red; }
            else if (moving) { _statePill.Text = el.Direction > 0 ? "MOVING UP" : "MOVING DOWN"; _statePill.PillColor = _accent; }
            else if (!doorsClosed) { _statePill.Text = "DOORS " + el.DoorStateText; _statePill.PillColor = Ui.Amber; }
            else { _statePill.Text = "READY"; _statePill.PillColor = Ui.Green; }

            if (emergency) { _interlockPill.Text = "INTERLOCK: EMERGENCY"; _interlockPill.PillColor = Ui.Red; }
            else if (!doorsClosed) { _interlockPill.Text = "INTERLOCK: DOOR OPEN"; _interlockPill.PillColor = Ui.Amber; }
            else { _interlockPill.Text = "INTERLOCK: SECURE"; _interlockPill.PillColor = Ui.Green; }

            BorderColor = emergency ? Ui.Red : Color.FromArgb(120, _accent);

            // ---- trip progress
            if (!moving) _moveFrom = el.Position;
            int target = el.TargetFloor != 0 ? el.TargetFloor : destination;
            double span = Math.Abs(target - _moveFrom);
            _progress.Value = moving && span > 0.001 ? Math.Abs(el.Position - _moveFrom) / span : 0;

            // ---- buttons: invalid controls are disabled (same rules as before: nothing in an emergency,
            //      no floor / movement while a door is not completely closed)
            bool canRequest = !emergency && doorsClosed;
            foreach (FlatButton b in _floorButtons)
            {
                int f = (int)b.Tag;
                bool here = el.IsAtFloor && el.CurrentFloor == f && !moving;
                b.Enabled = canRequest && !here && !el.IsRequested(f);
                b.Lit = el.IsRequested(f);
            }

            bool canTravel = canRequest && !moving;
            _btnUp.Enabled = canTravel && el.NextFloorAbove <= Elevator.MaxFloor;
            _btnDown.Enabled = canTravel && el.NextFloorBelow >= Elevator.MinFloor;
            _btnUp.Lit = moving && el.Direction > 0;
            _btnDown.Lit = moving && el.Direction < 0;

            bool canDoor = !emergency && !moving && el.IsAtFloor;
            _btnOpen.Enabled = canDoor && !el.DoorTargetOpen;
            _btnClose.Enabled = canDoor && el.DoorTargetOpen;

            _btnEmergency.Enabled = !emergency;
            _btnEmergency.Lit = emergency;
            _btnAlarm.Enabled = true;
            _btnAlarm.Lit = alarm;
            _btnReset.Enabled = emergency || alarm;

            // ---- why is something disabled?
            string hint; Color hintColor = Ui.Amber;
            if (emergency) { hint = "Emergency stop is active - press Reset to clear it."; hintColor = Ui.Red; }
            else if (moving) hint = "Cabin is travelling - controls unlock when it arrives.";
            else if (el.Overload) hint = "Overload - movement is blocked until the load is reduced.";
            else if (!doorsClosed) hint = "Doors are not closed - the cabin cannot move until they are.";
            else if (alarm) hint = "Alarm active - press Reset to stop it.";
            else if (!_btnUp.Enabled && el.CurrentFloor >= Elevator.MaxFloor) { hint = "Top floor - only Move Down is available."; hintColor = Ui.Muted; }
            else if (!_btnDown.Enabled && el.CurrentFloor <= Elevator.MinFloor) { hint = "Ground floor - only Move Up is available."; hintColor = Ui.Muted; }
            else { hint = "Ready for requests."; hintColor = Ui.Muted; }
            _hint.Text = hint;
            _hint.ForeColor = hintColor;
        }

        private static Color DoorColor(Door door)
        {
            if (door == null) return Ui.Text;
            switch (door.State)
            {
                case DoorState.Open: return Ui.Green;
                case DoorState.Opening:
                case DoorState.Closing: return Ui.Amber;
                default: return Ui.Text;
            }
        }
    }
}
