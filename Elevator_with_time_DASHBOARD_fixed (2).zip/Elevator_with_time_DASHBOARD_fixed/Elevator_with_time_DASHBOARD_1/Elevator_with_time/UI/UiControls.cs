using System.ComponentModel;
using System.Drawing.Drawing2D;

namespace Elevator_with_time
{
    /// <summary>Rounded rectangle helper for the flat dashboard controls.</summary>
    internal static class Round
    {
        public static GraphicsPath Rect(Rectangle r, int radius)
        {
            int d = Math.Max(2, radius * 2);
            var p = new GraphicsPath();
            p.AddArc(r.Left, r.Top, d, d, 180, 90);
            p.AddArc(r.Right - d, r.Top, d, d, 270, 90);
            p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            p.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
            p.CloseFigure();
            return p;
        }
    }

    /// <summary>A dark surface with rounded corners and a subtle border (the "card" of the dashboard).</summary>
    public class RoundedPanel : Panel
    {
        private Color _border = Ui.Border;
        private Color _fill = Ui.Surface;

        public RoundedPanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Ui.Surface;
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Color BorderColor { get => _border; set { if (_border == value) return; _border = value; Invalidate(); } }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Color FillColor
        {
            get => _fill;
            set { _fill = value; BackColor = value; Invalidate(); }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Parent != null ? Parent.BackColor : Ui.Bg);
            if (Width < 6 || Height < 6) return;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = new Rectangle(0, 0, Width - 1, Height - 1);
            using GraphicsPath path = Round.Rect(r, 12);
            using (var fill = new SolidBrush(_fill)) g.FillPath(fill, path);
            using (var pen = new Pen(_border, 1)) g.DrawPath(pen, path);
        }
    }

    /// <summary>Flat modern button with enabled / hover / pressed / active (lit) / disabled states.</summary>
    public class FlatButton : Button
    {
        private bool _hover, _down, _lit;
        private Color _accent = Ui.Blue;
        private Color _solid = Color.Empty;

        public FlatButton()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            FlatStyle = FlatStyle.Flat;
            TabStop = false;
            Cursor = Cursors.Hand;
            Font = Ui.Face(10F, FontStyle.Bold);
        }

        /// <summary>Colour of the border / glow when the button is active (lit).</summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Color Accent { get => _accent; set { _accent = value; Invalidate(); } }

        /// <summary>Solid fill colour (used by EMERGENCY STOP). Empty = normal dark button.</summary>
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Color Solid { get => _solid; set { _solid = value; Invalidate(); } }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool Lit { get => _lit; set { if (_lit == value) return; _lit = value; Invalidate(); } }

        protected override void OnEnabledChanged(EventArgs e) { Cursor = Enabled ? Cursors.Hand : Cursors.Default; Invalidate(); base.OnEnabledChanged(e); }
        protected override void OnMouseEnter(EventArgs e) { _hover = true; Invalidate(); base.OnMouseEnter(e); }
        protected override void OnMouseLeave(EventArgs e) { _hover = false; _down = false; Invalidate(); base.OnMouseLeave(e); }
        protected override void OnMouseDown(MouseEventArgs e) { _down = true; Invalidate(); base.OnMouseDown(e); }
        protected override void OnMouseUp(MouseEventArgs e) { _down = false; Invalidate(); base.OnMouseUp(e); }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Parent != null ? Parent.BackColor : Ui.Surface);
            if (Width < 6 || Height < 6) return;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            Color fill, border, text;
            if (!Enabled)
            {
                fill = Color.FromArgb(24, 31, 48);
                border = Color.FromArgb(36, 46, 68);
                text = Color.FromArgb(88, 100, 124);
            }
            else if (_solid != Color.Empty)
            {
                fill = _down ? ControlPaint.Dark(_solid, 0.15f) : _hover ? ControlPaint.Light(_solid, 0.12f) : _solid;
                border = _lit ? Color.White : ControlPaint.Dark(_solid, 0.1f);
                text = Color.White;
            }
            else if (_lit)
            {
                fill = Color.FromArgb(_down ? 90 : 70, _accent);
                border = _accent;
                text = Color.White;
            }
            else
            {
                fill = _down ? Color.FromArgb(22, 29, 46) : _hover ? Color.FromArgb(40, 52, 80) : Ui.SurfaceAlt;
                border = _hover ? _accent : Ui.Border;
                text = Ui.Text;
            }

            var body = new Rectangle(1, 1, Width - 3, Height - 3);
            using GraphicsPath path = Round.Rect(body, 8);
            using (var fb = new SolidBrush(fill)) g.FillPath(fb, path);
            using (var pen = new Pen(border, _lit && Enabled ? 2 : 1)) g.DrawPath(pen, path);

            TextRenderer.DrawText(g, Text, Font, ClientRectangle, text,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
        }
    }

    /// <summary>Small rounded status label ("READY", "EMERGENCY", ...), coloured by meaning.</summary>
    public class StatusPill : Control
    {
        private Color _color = Ui.Green;

        public StatusPill()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor, true);
            Font = Ui.Face(9F, FontStyle.Bold);
            Height = 28;
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Color PillColor { get => _color; set { if (_color == value) return; _color = value; Invalidate(); } }

        public override string Text
        {
            get => base.Text;
            set { if (base.Text == value) return; base.Text = value; Invalidate(); }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Parent != null ? Parent.BackColor : Ui.Surface);
            if (Width < 8 || Height < 8) return;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = new Rectangle(0, 0, Width - 1, Height - 1);
            using GraphicsPath path = Round.Rect(r, Height / 2);
            using (var fb = new SolidBrush(Color.FromArgb(45, _color))) g.FillPath(fb, path);
            using (var pen = new Pen(Color.FromArgb(150, _color), 1)) g.DrawPath(pen, path);
            int dot = Math.Max(6, Height / 3);
            using (var db = new SolidBrush(_color)) g.FillEllipse(db, 10, (Height - dot) / 2, dot, dot);
            var textArea = new Rectangle(10 + dot + 6, 0, Width - (10 + dot + 6) - 8, Height);
            TextRenderer.DrawText(g, Text, Font, textArea, _color,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
        }
    }

    /// <summary>Thin progress bar showing how far the cabin is on its way to the destination.</summary>
    public class MoveProgress : Control
    {
        private double _value;
        private Color _accent = Ui.Blue;

        public MoveProgress()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Height = 8;
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public double Value
        {
            get => _value;
            set { value = Math.Clamp(value, 0, 1); if (Math.Abs(value - _value) < 0.004) return; _value = value; Invalidate(); }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Color Accent { get => _accent; set { _accent = value; Invalidate(); } }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Parent != null ? Parent.BackColor : Ui.Surface);
            if (Width < 8 || Height < 4) return;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var track = new Rectangle(0, 0, Width - 1, Height - 1);
            using (GraphicsPath p = Round.Rect(track, Height / 2))
            using (var tb = new SolidBrush(Color.FromArgb(34, 44, 66)))
                g.FillPath(tb, p);
            int w = (int)Math.Round((Width - 1) * _value);
            if (w < Height) return;
            using (GraphicsPath p = Round.Rect(new Rectangle(0, 0, w, Height - 1), Height / 2))
            using (var fb = new SolidBrush(_accent))
                g.FillPath(fb, p);
        }
    }

    /// <summary>The application icon: a rounded square with an up and a down arrow.</summary>
    public class AppIcon : Control
    {
        public AppIcon()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Size = new Size(36, 36);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Parent != null ? Parent.BackColor : Ui.Bg);
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var r = new Rectangle(0, 0, Width - 1, Height - 1);
            using (GraphicsPath p = Round.Rect(r, 9))
            using (var fb = new LinearGradientBrush(r, Ui.Blue, Ui.Violet, 45f))
                g.FillPath(fb, p);
            float cx = Width / 2f, s = Width * 0.17f;
            using var white = new SolidBrush(Color.White);
            g.FillPolygon(white, new[] { new PointF(cx, Height * 0.2f), new PointF(cx - s, Height * 0.2f + s * 1.5f), new PointF(cx + s, Height * 0.2f + s * 1.5f) });
            g.FillPolygon(white, new[] { new PointF(cx, Height * 0.8f), new PointF(cx - s, Height * 0.8f - s * 1.5f), new PointF(cx + s, Height * 0.8f - s * 1.5f) });
        }
    }
}
