namespace Elevator_with_time
{
    /// <summary>Delegate used to animate the elevator (raised on every timer tick while something moves).</summary>
    public delegate void PositionChangedHandler(Elevator elevator);

    /// <summary>Observer pattern: anyone interested in elevator events implements this.</summary>
    public interface IElevatorObserver
    {
        void OnElevatorEvent(Elevator elevator, string status);
    }

    /// <summary>State pattern: each state decides how the elevator reacts to timer ticks.</summary>
    public interface IElevatorState
    {
        string Name { get; }
        void OnEnter(Elevator e);
        void Tick(Elevator e);
    }

    /// <summary>The five states a door can be in.</summary>
    public enum DoorState { Closed, Opening, Open, Closing, Locked }

    /// <summary>
    /// One physical door (the inner cabin door, or the outer landing door of one floor).
    /// Openness: 0 = closed, 1 = fully open. The picture of the door is drawn from these two values only.
    /// </summary>
    public class Door
    {
        public Door(string name, DoorState initial)
        {
            Name = name;
            State = initial;
        }

        public string Name { get; }
        public DoorState State { get; internal set; }
        public double Openness { get; internal set; }

        public string Text => State.ToString().ToUpperInvariant();

        /// <summary>True when the door leaf is completely shut and bolted/closed (not opening, not open, not closing).</summary>
        public bool IsSecured => Openness <= 0.0 && (State == DoorState.Closed || State == DoorState.Locked);
    }

    /// <summary>
    /// ONE elevator serving the floors MinFloor..MaxFloor (floor 1 is shown as "G").
    ///
    /// DUAL DOOR SYSTEM
    ///   * Inner (cabin) door : belongs to the cabin and travels with it.
    ///   * Outer (landing) doors: one per floor, fixed to the building, they never move with the cabin.
    ///   The landing door of a floor is coupled to the cabin door only while the cabin is stopped and levelled at
    ///   exactly that floor. Both doors then open and close together (same speed, same moment).
    ///
    /// SAFETY INTERLOCK
    ///   * the cabin only moves while the inner door and EVERY landing door are completely closed,
    ///   * all doors are LOCKED while the cabin travels,
    ///   * a landing door is only unlocked / opened for the floor the cabin is levelled at and stopped on.
    ///
    /// A single System.Windows.Forms.Timer drives the cabin movement and the door animation.
    /// </summary>
    public class Elevator : IDisposable
    {
        public const int MinFloor = 1;                    // G
        public const int MaxFloor = 2;                    // G and 1 only
        public const int TickMs = 20;                     // timer interval
        public const double MaxSpeed = 0.022;             // floors per tick at cruising speed (about 1 s per floor)
        public const double RampDistance = 0.30;          // floors used to speed up / slow down
        public const double ApproachDistance = 0.50;      // announce approach when this close to the target floor
        public const double LevelDistance = 0.08;         // announce levelling when this close to the target floor
        public const double MinSpeedFactor = 0.30;        // creeping speed while levelling (share of MaxSpeed)
        public const double BrakeDistance = 0.35;         // a new stop can only be added if it is at least this far ahead
        public const int MaxLoadKg = 800;                 // rated load of the cabin
        public const double DoorStep = 0.03;              // doors need about 0.7 s to open / close
        public const int DoorDwellTicks = 4000 / TickMs;  // doors stay open for 4 s
        public const int ShortDwellTicks = 1500 / TickMs; // ... or only 1.5 s more once another floor was requested

        private readonly List<IElevatorObserver> _observers = new();
        private string _lastRefusal;                       // last MOVE REFUSED reason (avoids flooding the log)
        private readonly System.Windows.Forms.Timer _timer;
        private readonly List<int> _pending = new();       // requested floors that have not been served yet
        private readonly Door[] _landing = new Door[MaxFloor + 1];

        private int _doorFloor;           // floor whose landing door is coupled to the cabin door (0 = no door cycle)
        private bool _doorWantOpen;       // true while the doors are opening / open
        private int _dwell;               // ticks the doors have been fully open

        public string Name { get; }
        public double Position { get; internal set; }       // 1.0 .. MaxFloor (fractional while moving)
        public int Direction { get; internal set; }         // +1 up, -1 down, 0 stopped
        public int LastDirection { get; internal set; } = 1;
        public int TargetFloor { get; internal set; }       // floor the cabin is travelling to (0 = none)
        public IElevatorState State { get; private set; }
        public string StatusText { get; internal set; } = "READY";

        /// <summary>The inner cabin door: it is part of the cabin and moves with it.</summary>
        public Door Inner { get; }

        /// <summary>The outer landing door of a floor: fixed to the building, never moves.</summary>
        public Door GetLanding(int floor) => _landing[floor];
        public double GetLandingOpenness(int floor) => _landing[floor].Openness;

        public bool AlarmActive { get; private set; }
        public DateTime AlarmStarted { get; private set; }

        public IReadOnlyList<int> Pending => _pending;
        public bool IsRequested(int floor) => _pending.Contains(floor);

        /// <summary>Load in the cabin (kg). Changed with SetLoad(), e.g. when passengers get in or out.</summary>
        public int Load { get; private set; }
        public bool Overload => Load > MaxLoadKg;

        /// <summary>Sets the cabin load. Only allowed while the cabin stands still. Logs OVERLOAD once when the limit is crossed.</summary>
        public void SetLoad(int kg)
        {
            if (kg < 0) throw new ArgumentOutOfRangeException(nameof(kg), "Load cannot be negative.");
            if (IsMoving) { Notify("LOAD CHANGE REFUSED: CABIN IS MOVING"); return; }

            bool wasOverloaded = Overload;
            Load = kg;
            if (Overload && !wasOverloaded)
                Notify($"OVERLOAD: {Load} KG (MAX {MaxLoadKg} KG) - MOVEMENT PREVENTED");
            else if (!Overload && wasOverloaded)
                Notify($"OVERLOAD CLEARED: {Load} KG - MOVEMENT ALLOWED");
        }

        public bool IsMoving => State is MovingState;
        public bool IsEmergency => State is EmergencyState;
        public bool IsAtFloor => Math.Abs(Position - Math.Round(Position)) < 1e-6;
        public int CurrentFloor => (int)Math.Round(Position, MidpointRounding.AwayFromZero);

        // ---------- door information ----------

        public double DoorOpenness => Inner.Openness;                    // 0 closed .. 1 fully open
        public bool DoorTargetOpen => _doorWantOpen;                     // true while doors are opening / open

        /// <summary>The inner door AND every landing door are completely closed (this is the movement interlock).</summary>
        public bool AllDoorsClosed
        {
            get
            {
                if (!Inner.IsSecured) return false;
                for (int f = MinFloor; f <= MaxFloor; f++)
                    if (!_landing[f].IsSecured) return false;
                return true;
            }
        }

        public bool DoorsFullyClosed => AllDoorsClosed;

        /// <summary>Movement is only possible when this is true.</summary>
        public bool CanMove => !IsEmergency && !IsMoving && AllDoorsClosed && !Overload;

        /// <summary>The landing door the cabin is currently standing at (null while travelling / between floors).</summary>
        public Door ActiveOuterDoor => (IsAtFloor && !IsMoving) ? _landing[CurrentFloor] : null;

        public string OuterDoorText
        {
            get
            {
                Door d = ActiveOuterDoor;
                return d == null ? "LOCKED" : $"{d.Text} [{FloorName(CurrentFloor)}]";
            }
        }

        /// <summary>One word for the whole door system: CLOSED, OPENING, OPEN, CLOSING or LOCKED.</summary>
        public string DoorStateText
        {
            get
            {
                Door outer = ActiveOuterDoor;
                if (outer == null) return "LOCKED";
                return Inner.Text;
            }
        }

        public string DoorText => DoorStateText;

        // ---------- destination ----------

        public int DestinationFloor => TargetFloor != 0 ? TargetFloor : ChooseNextTarget();
        public int NextFloorAbove => (int)Math.Floor(Position + 1e-6) + 1;
        public int NextFloorBelow => (int)Math.Ceiling(Position - 1e-6) - 1;

        public event PositionChangedHandler PositionChanged;
        public event PositionChangedHandler DoorsChanged;

        public Elevator(string name, int startFloor)
        {
            if (startFloor < MinFloor || startFloor > MaxFloor)
                throw new ArgumentOutOfRangeException(nameof(startFloor));

            Name = name;
            Position = startFloor;
            TargetFloor = 0;
            Inner = new Door("Inner door", DoorState.Closed);
            for (int f = MinFloor; f <= MaxFloor; f++)
                _landing[f] = new Door($"Landing door {FloorName(f)}", f == startFloor ? DoorState.Closed : DoorState.Locked);
            State = new IdleState();

            _timer = new System.Windows.Forms.Timer { Interval = TickMs };
            _timer.Tick += (s, e) => { AnimateDoors(); State.Tick(this); };
            _timer.Start();
        }

        // ---------- floor names (floor 1 = G, floor 2 = "1", floor 3 = "2") ----------
        public static string FloorName(int floor) => floor == 1 ? "G" : (floor - 1).ToString();
        public static string FloorLongName(int floor) => floor == 1 ? "Ground Floor" : floor == 2 ? "First Floor" : $"Floor {floor - 1}";

        /// <summary>Upper-case floor name used in the event log: "GROUND FLOOR", "FLOOR 1", "FLOOR 2".</summary>
        public static string FloorTag(int floor) => floor == 1 ? "GROUND FLOOR" : $"FLOOR {floor - 1}";

        // ---------- Observer ----------
        public void Attach(IElevatorObserver observer) => _observers.Add(observer);

        public void Notify(string status)
        {
            foreach (var o in _observers.ToArray())
                o.OnElevatorEvent(this, status);
        }

        internal void RaisePositionChanged() => PositionChanged?.Invoke(this);
        internal void RaiseDoorsChanged() => DoorsChanged?.Invoke(this);

        internal void SetState(IElevatorState newState)
        {
            State = newState;
            newState.OnEnter(this);
        }

        // =====================================================================================
        //  Floor requests and dispatching
        // =====================================================================================

        /// <summary>
        /// Registers a request for a floor. The cabin goes there as soon as the safety interlock allows
        /// (all doors closed). A request for the floor the cabin is standing at simply opens the doors.
        /// </summary>
        public void RequestFloor(int floor)
        {
            if (floor < MinFloor || floor > MaxFloor)
                throw new ArgumentOutOfRangeException(nameof(floor), "Unknown floor.");

            if (IsEmergency) { Notify("REQUEST REFUSED: EMERGENCY STOP IS ACTIVE"); return; }

            // the cabin is already levelled at that floor: just open the doors (if they are closed / closing)
            if (!IsMoving && IsAtFloor && CurrentFloor == floor)
            {
                OpenDoors();
                return;
            }

            if (_pending.Contains(floor)) return;     // already requested
            _pending.Add(floor);
            Notify($"REQUESTED {FloorTag(floor)}");

            if (IsMoving)
                RetargetWhileMoving();                // a stop on the way may be possible
            else if (_doorWantOpen && Inner.State == DoorState.Open)
                _dwell = Math.Max(_dwell, DoorDwellTicks - ShortDwellTicks);   // somebody is waiting: close soon
        }

        /// <summary>Picks the next stop: keep the travelling direction while there are requests ahead.</summary>
        private int ChooseNextTarget()
        {
            if (_pending.Count == 0) return 0;

            int best = 0;
            double bestDist = double.MaxValue;
            foreach (int f in _pending)
            {
                double ahead = (f - Position) * LastDirection;
                if (ahead > 1e-9 && ahead < bestDist) { best = f; bestDist = ahead; }
            }
            if (best != 0) return best;

            foreach (int f in _pending)                // nothing ahead: nearest request in the other direction
            {
                double d = Math.Abs(f - Position);
                if (d < bestDist) { best = f; bestDist = d; }
            }
            return best;
        }

        /// <summary>While travelling: a requested floor that is far enough ahead becomes the new (nearer) stop.</summary>
        private void RetargetWhileMoving()
        {
            if (!IsMoving || Direction == 0) return;

            int best = TargetFloor;
            double bestDist = Math.Abs(TargetFloor - Position);
            foreach (int f in _pending)
            {
                double ahead = (f - Position) * Direction;
                if (ahead >= BrakeDistance && ahead < bestDist) { best = f; bestDist = ahead; }
            }
            if (best != TargetFloor)
            {
                TargetFloor = best;
                Notify($"STOP ADDED AT {FloorTag(best)}");
            }
        }

        /// <summary>Called on every tick while the cabin stands still (IdleState).</summary>
        /// 
        internal void IdleTick()
        {
            // a cabin that is levelled at a floor (e.g. after a RESET) releases the doors of THAT floor only
            if (IsAtFloor) UnlockDoorZone(CurrentFloor);

            if (_doorFloor != 0) return;               // a door cycle is running: wait until it is finished
            if (!AllDoorsClosed) return;               // interlock: never start while any door is not closed

            if (_pending.Count > 0)
            {
                StartNextMove();
                return;
            }

            if (StatusText != "READY")
            {
                StatusText = "READY";
                Notify("READY");
            }
        }

        private void StartNextMove()
        {
            int target = ChooseNextTarget();
            if (target == 0) return;

            // a request for the floor we stand on: no travel, just serve it with the doors
            if (IsAtFloor && CurrentFloor == target)
            {
                _pending.Remove(target);
                BeginOpen(target);
                return;
            }

            if (Overload)
            {
                RefuseOnce("MOVE REFUSED: OVERLOAD - REDUCE LOAD");
                return;
            }
            if (!AllDoorsClosed)
            {
                RefuseOnce("MOVE REFUSED: DOOR IS NOT CLOSED");
                return;
            }

            TargetFloor = target;
            _lastRefusal = null;
            ApproachLogged = LevelLogged = false;
            LockDoorsForTravel();
            SetState(new MovingState());
        }

        public int NextPendingFloor => ChooseNextTarget();


        /// <summary>Logs a refusal only when the reason changes (the dispatcher asks every tick).</summary>
        private void RefuseOnce(string reason)
        {
            if (reason == _lastRefusal) return;
            _lastRefusal = reason;
            Notify(reason);
        }

        /// <summary>Approach / levelling announcements of one trip (called by MovingState).</summary>
        internal bool ApproachLogged, LevelLogged;

        // =====================================================================================
        //  Doors
        // =====================================================================================

        /// <summary>Opens the inner door together with the landing door of the floor the cabin is levelled at.</summary>
        public void OpenDoors()
        {
            if (IsEmergency || IsMoving || !IsAtFloor || _doorWantOpen) return;
            BeginOpen(CurrentFloor);
        }

        /// <summary>Closes the inner door together with the landing door it is coupled to.</summary>
        public void CloseDoors()
        {
            if (IsEmergency || IsMoving || !_doorWantOpen) return;
            BeginClose();
        }

        /// <summary>Releases the inner door and the landing door of ONE floor (the floor the cabin is levelled at).</summary>
        private void UnlockDoorZone(int floor)
        {
            if (IsMoving || !IsAtFloor || CurrentFloor != floor) return;
            Door outer = _landing[floor];
            if (Inner.State != DoorState.Locked && outer.State != DoorState.Locked) return;

            if (Inner.State == DoorState.Locked) Inner.State = DoorState.Closed;
            if (outer.State == DoorState.Locked) outer.State = DoorState.Closed;
            Notify("DOORS UNLOCKED");
        }

        /// <summary>Interlock: before the cabin leaves, the inner door and every landing door are locked.</summary>
        private void LockDoorsForTravel()
        {
            Inner.State = DoorState.Locked;
            for (int f = MinFloor; f <= MaxFloor; f++)
                _landing[f].State = DoorState.Locked;
            Notify("ALL DOORS LOCKED");
        }

        private void BeginOpen(int floor)
        {
            // the landing door only ever opens for the floor where the cabin is levelled AND stopped
            if (IsEmergency || IsMoving || !IsAtFloor || CurrentFloor != floor) return;

            UnlockDoorZone(floor);
            Door outer = _landing[floor];

            _doorFloor = floor;
            _doorWantOpen = true;
            _dwell = 0;
            Inner.State = DoorState.Opening;
            outer.State = DoorState.Opening;
            StatusText = "DOORS OPENING";
            Notify("INNER DOOR OPENING");
            Notify($"{FloorTag(floor)} OUTER DOOR OPENING");
        }

        private void BeginClose()
        {
            if (_doorFloor == 0) return;
            Door outer = _landing[_doorFloor];
            _doorWantOpen = false;
            Inner.State = DoorState.Closing;
            outer.State = DoorState.Closing;
            StatusText = "DOORS CLOSING";
            Notify("DOORS CLOSING");
        }

        /// <summary>
        /// Moves the cabin door and the coupled landing door one step (called every timer tick).
        /// Both doors always get exactly the same openness: they open and close together.
        /// </summary>
        private void AnimateDoors()
        {
            if (_doorFloor == 0) return;
            Door outer = _landing[_doorFloor];

            if (_doorWantOpen)
            {
                if (Inner.Openness < 1.0)
                {
                    double v = Math.Min(1.0, Inner.Openness + DoorStep);
                    Inner.Openness = v;
                    outer.Openness = v;
                    RaiseDoorsChanged();

                    if (v >= 1.0)
                    {
                        Inner.State = DoorState.Open;
                        outer.State = DoorState.Open;
                        _dwell = 0;
                        StatusText = "DOORS OPEN";
                        Notify("DOORS OPEN");
                    }
                }
                else if (++_dwell >= DoorDwellTicks && !Overload)
                {
                    BeginClose();                      // passengers had their time: close automatically
                }
            }
            else if (Inner.Openness > 0.0)
            {
                double v = Math.Max(0.0, Inner.Openness - DoorStep);
                Inner.Openness = v;
                outer.Openness = v;
                RaiseDoorsChanged();

                if (v <= 0.0)
                {
                    Inner.State = DoorState.Closed;
                    outer.State = DoorState.Closed;
                    _doorFloor = 0;
                    StatusText = "DOORS CLOSED";
                    Notify("DOORS CLOSED");
                }
            }
        }

        // =====================================================================================
        //  Travel events (called by MovingState)
        // =====================================================================================

        internal void AnnouncePassing(double from, double to)
        {
            for (int f = MinFloor; f <= MaxFloor; f++)
            {
                if (f == TargetFloor) continue;
                bool crossed = (from < f && to >= f) || (from > f && to <= f);
                if (crossed) Notify($"PASSING {FloorTag(f)} - LANDING DOOR STAYS LOCKED");
            }
        }

        /// <summary>The cabin is levelled exactly at TargetFloor: stop, unlock that floor's doors and open them.</summary>
        internal void CompleteArrival()
        {
            int floor = CurrentFloor;
            _pending.Remove(floor);
            TargetFloor = 0;
            SetState(new IdleState());                 // direction = 0
            StatusText = "ARRIVED";
            Notify($"ARRIVED AT {FloorTag(floor)}");

            UnlockDoorZone(floor);                     // only THIS floor's landing door is released
            BeginOpen(floor);                          // inner door + this floor's outer door open together
        }

        /// <summary>Safety interlock violated while travelling: halt the drive at once.</summary>
        internal void HaltDrive(string reason)
        {
            if (IsEmergency) return;
            Notify(reason);
            EmergencyStop();
        }

        // =====================================================================================
        //  Safety
        // =====================================================================================

        /// <summary>Stops the timer at once: cabin and doors freeze, requests are dropped, nothing moves until RESET.</summary>
        public void EmergencyStop()
        {
            if (IsEmergency) return;
            _timer.Stop();
            _pending.Clear();
            TargetFloor = 0;
            StatusText = "EMERGENCY STOP";
            SetState(new EmergencyState());
        }

        /// <summary>Clears the emergency state (and a running alarm); the elevator is IDLE again.</summary>
        public void Reset()
        {
            if (IsEmergency)
            {
                AlarmActive = false;
                StatusText = "RESET";
                SetState(new IdleState());
                _timer.Start();
                Notify("RESET - EMERGENCY STOP CLEARED");
            }
            else if (AlarmActive)
            {
                ClearAlarm("RESET - ALARM CLEARED");
            }
        }

        public void RaiseAlarm()
        {
            AlarmActive = true;
            AlarmStarted = DateTime.Now;
            try { System.Media.SystemSounds.Hand.Play(); } catch { /* no sound device: ignore */ }
            Notify("ALARM ACTIVATED");
        }

        public void ClearAlarm(string reason)
        {
            if (!AlarmActive) return;
            AlarmActive = false;
            Notify(reason);
        }

        public void Dispose()
        {
            _timer.Stop();
            _timer.Dispose();
        }
    }
}
