namespace Elevator_with_time
{
    /// <summary>
    /// Elevator is standing still (at a floor, or between floors after an emergency reset).
    /// Every tick it hands over to the dispatcher: serve the next request as soon as all doors are closed.
    /// </summary>
    internal class IdleState : IElevatorState
    {
        public string Name => "Idle";

        public void OnEnter(Elevator e) => e.Direction = 0;

        public void Tick(Elevator e) => 
            
            
            e.IdleTick();
    }

    /// <summary>
    /// Elevator cabin is travelling to Elevator.TargetFloor. The cabin speeds up, cruises and slows down
    /// ("levelling") and stops exactly on the floor level. The door interlock is checked on every tick.
    /// </summary>
    internal class MovingState : IElevatorState
    {
        private double _start;

        public string Name => "Moving";

        public void OnEnter(Elevator e)
        {
            _start = e.Position;
            e.Direction = Math.Sign(e.TargetFloor - e.Position);
            e.LastDirection = e.Direction;
            e.StatusText = "MOVING";

            string from = Elevator.FloorTag(e.CurrentFloor);
            string to = Elevator.FloorTag(e.TargetFloor);
            e.Notify(e.Direction > 0 ? $"GOING UP: {from} TO {to}" : $"GOING DOWN: {from} TO {to}");
        }

        public void Tick(Elevator e)
        {
            // safety interlock: the cabin must never travel with a door that is not closed
            if (!e.AllDoorsClosed)
            {
                e.HaltDrive("INTERLOCK FAULT: DOOR NOT CLOSED WHILE MOVING");
                return;
            }

            double diff = e.TargetFloor - e.Position;
            double dist = Math.Abs(diff);

            // speed profile: slow at the start and in front of the target, fast in between
            double ramp = Math.Min(Math.Abs(e.Position - _start), dist);
            double speed = Elevator.MaxSpeed * Math.Clamp(ramp / Elevator.RampDistance, Elevator.MinSpeedFactor, 1.0);
            if (dist <= speed)
            {
                // levelled exactly with the floor: stop, then doors
                e.Position = e.TargetFloor;
                e.RaisePositionChanged();
                e.CompleteArrival();
                return;
            }

            // announce the phases of the approach once per trip
            if (!e.ApproachLogged && dist <= Elevator.ApproachDistance)
            {
                e.ApproachLogged = true;
                e.Notify($"APPROACHING {Elevator.FloorTag(e.TargetFloor)}");
            }
            if (!e.LevelLogged && dist <= Elevator.LevelDistance)
            {
                e.LevelLogged = true;
                e.Notify("LEVELING");
            }

            double before = e.Position;
            e.Position += Math.Sign(diff) * speed;
            e.AnnouncePassing(before, e.Position);
            e.RaisePositionChanged();
        }
    }

    /// <summary>Emergency stop: the timer is stopped, nothing moves until RESET.</summary>
    internal class EmergencyState : IElevatorState
    {
        public string Name => "Emergency";

        public void OnEnter(Elevator e)
        {
            e.Direction = 0;
            e.Notify("EMERGENCY STOP ACTIVATED");
        }

        public void Tick(Elevator e) { }
    }
}
