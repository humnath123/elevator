namespace Elevator_with_time
{
    /// <summary>
    /// Run-time wiring of the dashboard. The visual layout itself lives in Form1.Designer.cs and in the
    /// controls of UI/Sections.cs (so it is visible in the designer); this file only connects the code to it.
    /// </summary>
    public partial class Form1
    {
        // top bar
        private StatusPill _pillSystem;
        private Label _lblClock;
        private FlatButton _btnLogs, _btnSettings, _btnExit;

        // overview
        private Label _ovA, _ovB, _ovMoves, _ovSafety, _ovLast;

        // activity log
        private Panel _hostLog;
        private ComboBox _cmbElevator;
        private TextBox _txtSearch;
        private DateTimePicker _dtpDate;
        private Label _lblCount, _lblEmpty, _lblDbStatus;
        private FlatButton _btnShowLog, _btnClearLog;
        private DataGridView _dgvLog;

        private void BindDashboard()
        {
            // top bar
            _pillSystem = _topBar.Pill;
            _lblClock = _topBar.Clock;
            _btnLogs = _topBar.LogsButton;
            _btnSettings = _topBar.SettingsButton;
            _btnExit = _topBar.ExitButton;
            _btnLogs.Click += btnLogs_Click;
            _btnSettings.Click += btnSettings_Click;
            _btnExit.Click += btnExit_Click;
            _lblClock.Text = "";

            // overview
            _ovA = _overview.ElevatorA;
            _ovB = _overview.ElevatorB;
            _ovMoves = _overview.Movements;
            _ovSafety = _overview.Safety;
            _ovLast = _overview.LatestEvent;

            // activity log
            _hostLog = _logPanel;
            _cmbElevator = _logPanel.ElevatorFilter;
            _txtSearch = _logPanel.SearchBox;
            _dtpDate = _logPanel.DateFilter;
            _lblCount = _logPanel.CountLabel;
            _lblEmpty = _logPanel.EmptyLabel;
            _lblDbStatus = _logPanel.DbStatusLabel;
            _btnShowLog = _logPanel.ShowLogButton;
            _btnClearLog = _logPanel.ClearLogButton;
            _dgvLog = _logPanel.Grid;

            _cmbElevator.SelectedIndexChanged += (s, e) => ApplyLogFilter();
            _txtSearch.TextChanged += (s, e) => ApplyLogFilter();
            _dtpDate.ValueChanged += (s, e) => ApplyLogFilter();
            _btnShowLog.Click += btnLog_Click;
            _btnClearLog.Click += btnClearLog_Click;
            _dgvLog.CellFormatting += DgvLog_CellFormatting;
        }
    }
}
