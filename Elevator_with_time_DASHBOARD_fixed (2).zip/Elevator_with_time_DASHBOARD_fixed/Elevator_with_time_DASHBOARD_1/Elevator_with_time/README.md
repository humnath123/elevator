# Elevator Simulator (C# WinForms, .NET 10, MySQL) - Dual Elevator Dashboard

Dark industrial dashboard with **two independent elevators**, A (blue accent) and B (violet accent).

* **Top bar**: app name, system status (online / alarm / emergency / database offline), date and time, Activity Logs, Settings, Exit.
* **Overview**: current floor and state of A and B, number of active movements, safety status, latest event - all computed from the live models.
* **Two elevator panels** (`ElevatorPanel.cs`): shaft with cabin and doors, status display, floor / movement / door / safety controls,
  interlock indicator, trip progress bar and a hint that says why a control is disabled. Each panel only talks to its own elevator.
* **Activity log**: ID, Date, Time, Elevator, Floor, Action, Status; filter by elevator, text and date; critical / warning rows coloured,
  newest row highlighted, empty-state message. Show Log, Clear Log and Exit stay available.
* The window resizes (panels, shafts and log follow it); below about 1260 px wide scroll bars appear instead of clipping.

Files added/changed: `ElevatorPanel.cs`, `UiControls.cs` (flat buttons, cards, pills), `Form1.cs`, `Form1.Dashboard.cs` (layout),
`Form1.Designer.cs`, `Theme.cs`, `Controls.cs` (per-shaft accent), `LogRepository.cs` (Status column). The simulation
(`Elevator.cs`, `ElevatorStates.cs`, `ElevatorController.cs`) and the MySQL table are unchanged.

## Run it
1. Start your MySQL server (127.0.0.1:3306, user root - see `dbsettings.json`).
2. Open `Elevator_with_time.sln` in Visual Studio and press F5 (first build needs internet for the NuGet package `MySqlConnector`).
3. The program creates database `elevator_db` and table `elevator_log` by itself (or run `Database\elevator_db.sql`).

## Door states and synchronisation
States: `CLOSED`, `OPENING`, `OPEN`, `CLOSING`, `LOCKED`.

* Arrival: cabin levels exactly on the floor -> `ARRIVED AT FLOOR n` -> inner door + **that floor's** outer door unlock
  -> `INNER DOOR OPENING`, `FLOOR n OUTER DOOR OPENING` -> both open together (same openness every tick) -> `DOORS OPEN`.
* The doors stay open for 4 s (1.5 s once another floor has been requested), then `DOORS CLOSING` -> `DOORS CLOSED` -> `READY`.
  `OPEN DOOR` / `CLOSE DOOR` work at any time while the cabin stands at a floor.
* Before leaving: `ALL DOORS LOCKED` - inner door and all landing doors are `LOCKED` while the cabin travels.

## Safety interlock
* The cabin only starts when the inner door **and every** landing door are completely closed.
* The interlock is re-checked on every movement tick (a violation triggers an emergency stop - `INTERLOCK FAULT`).
* A landing door only unlocks/opens for the floor the cabin is levelled at and stopped on; all other floors stay `LOCKED`.
* **EMERGENCY STOP** stops the timer at once (cabin and doors freeze), drops all requests and blocks everything until **RESET**.
* **ALARM**: flashing lamp/message, repeating tone, log entry, stops by itself after 6 s or with RESET.
* Invalid controls are disabled automatically: no DOWN at G, no UP at the top floor, no floor/UP/DOWN while a door is open,
  opening or closing, nothing but ALARM/RESET during an emergency stop.

## Requests and movement
Floor buttons (and the call buttons on the wall) put floors into a request queue (`Requests:` line, lit buttons).
The cabin keeps its direction while there are requests ahead, may add a stop on the way, speeds up / slows down
and levels exactly on the floor. `UP`/`DOWN` request the next floor above/below.

## Control panel
Status display: Current Floor, Destination, Direction, Inner Door, Outer Door, Door State, Status, Requests;
lamps: EMERGENCY, ALARM, INTERLOCK (green = movement allowed, amber = a door is not closed, red = emergency); digital clock.
Groups: FLOOR, MOVEMENT, DOOR, SAFETY (EMERGENCY STOP, ALARM, RESET). Right side: Show Log, Clear Log, Exit and the log grid.

## Event log (MySQL, ID / Date / Time / Elevator / Floor / Action)
`SYSTEM STARTED`, `REQUESTED FLOOR 2`, `ALL DOORS LOCKED`, `GOING UP: GROUND FLOOR TO FLOOR 2`, `PASSING FLOOR 1 - LANDING DOOR STAYS LOCKED`,
`STOP ADDED AT ...`, `ARRIVED AT FLOOR 2`, `DOORS UNLOCKED`, `INNER DOOR OPENING`, `FLOOR 2 OUTER DOOR OPENING`, `DOORS OPEN`,
`DOORS CLOSING`, `DOORS CLOSED`, `READY`, `EMERGENCY STOP ACTIVATED`, `ALARM ACTIVATED`, `RESET - ...`, `INTERLOCK FAULT ...`.

## Files
- `Elevator.cs` - model: `Door` / `DoorState`, request queue, door synchronisation, interlock, emergency, alarm
- `ElevatorStates.cs` - State pattern: Idle (dispatcher) / Moving (speed profile, levelling, interlock check) / Emergency
- `ElevatorController.cs` - controller + `LogObserver` (every event is written to MySQL)
- `Controls.cs` - `ElevatorShaft` (cabin + landing doors), `DoorArt`, `SteelButton`, `SteelPanel`, `LedDisplay`, `DisplayLabel`/`DisplayPanel`, `SectionLabel`
- `Theme.cs` - the colour theme and `Ui` dashboard colours
- `LogRepository.cs` - MySQL access (reads the extra `Floor` column from `floor_no`; table unchanged)

## Table `elevator_log` (unchanged)
| Column        | Type            | Meaning                          |
|---------------|-----------------|----------------------------------|
| log_id        | INT AUTO_INCREMENT PK | record number              |
| elevator_name | VARCHAR(20)     | "Elevator"                       |
| floor_no      | TINYINT         | 1 = G, 2 = 1, 3 = 2              |
| status        | VARCHAR(120)    | what happened                    |
| log_time      | DATETIME(3)     | date and time of the event       |

## Folder layout
- `Models/` - Elevator.cs, ElevatorStates.cs, ElevatorController.cs (simulation; lift speed is `Elevator.MaxSpeed`)
- `UI/` - Controls.cs, UiControls.cs, ElevatorPanel.cs, Theme.cs
- `Data/` - LogRepository.cs (MySQL)
- `Database/` - elevator_db.sql, `Docs/` - notes; Form1*.cs, Program.cs, dbsettings.json stay in the project root
