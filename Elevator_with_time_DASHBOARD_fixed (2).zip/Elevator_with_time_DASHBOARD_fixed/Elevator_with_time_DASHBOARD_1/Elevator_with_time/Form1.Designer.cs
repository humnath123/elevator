namespace Elevator_with_time
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify the contents of this method with the code editor.
        ///  The layout is: top bar, overview cards, activity log (bottom) and, filling the rest, the two elevator panels.
        /// </summary>
        private void InitializeComponent()
        {
            this._centerPanel = new System.Windows.Forms.Panel();
            this._grid = new System.Windows.Forms.TableLayoutPanel();
            this._panelA = new Elevator_with_time.ElevatorPanel();
            this._panelB = new Elevator_with_time.ElevatorPanel();
            this._logPanel = new Elevator_with_time.LogView();
            this._overview = new Elevator_with_time.OverviewView();
            this._topBar = new Elevator_with_time.TopBarView();
            this._centerPanel.SuspendLayout();
            this._grid.SuspendLayout();
            this.SuspendLayout();
            // 
            // _centerPanel
            // 
            this._centerPanel.AutoScroll = true;
            this._centerPanel.AutoScrollMinSize = new System.Drawing.Size(1260, 480);
            this._centerPanel.BackColor = System.Drawing.Color.FromArgb(13, 17, 28);
            this._centerPanel.Controls.Add(this._grid);
            this._centerPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._centerPanel.Name = "_centerPanel";
            this._centerPanel.TabIndex = 0;
            // 
            // _grid
            // 
            this._grid.BackColor = System.Drawing.Color.FromArgb(13, 17, 28);
            this._grid.ColumnCount = 2;
            this._grid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this._grid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this._grid.Controls.Add(this._panelA, 0, 0);
            this._grid.Controls.Add(this._panelB, 1, 0);
            this._grid.Dock = System.Windows.Forms.DockStyle.Fill;
            this._grid.Name = "_grid";
            this._grid.Padding = new System.Windows.Forms.Padding(12, 0, 12, 10);
            this._grid.RowCount = 1;
            this._grid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this._grid.TabIndex = 0;
            // 
            // _panelA  (Elevator A - bound to its elevator in the Form1 constructor)
            // 
            this._panelA.Dock = System.Windows.Forms.DockStyle.Fill;
            this._panelA.Margin = new System.Windows.Forms.Padding(0, 0, 6, 0);
            this._panelA.Name = "_panelA";
            this._panelA.TabIndex = 0;
            // 
            // _panelB  (Elevator B - bound to its elevator in the Form1 constructor)
            // 
            this._panelB.Dock = System.Windows.Forms.DockStyle.Fill;
            this._panelB.Margin = new System.Windows.Forms.Padding(6, 0, 0, 0);
            this._panelB.Name = "_panelB";
            this._panelB.TabIndex = 1;
            // 
            // _logPanel
            // 
            this._logPanel.BackColor = System.Drawing.Color.FromArgb(13, 17, 28);
            this._logPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this._logPanel.Name = "_logPanel";
            this._logPanel.Padding = new System.Windows.Forms.Padding(12, 0, 12, 12);
            this._logPanel.Size = new System.Drawing.Size(1440, 190);
            this._logPanel.TabIndex = 1;
            // 
            // _overview
            // 
            this._overview.BackColor = System.Drawing.Color.FromArgb(13, 17, 28);
            this._overview.Dock = System.Windows.Forms.DockStyle.Top;
            this._overview.Name = "_overview";
            this._overview.Padding = new System.Windows.Forms.Padding(12, 10, 12, 8);
            this._overview.Size = new System.Drawing.Size(1440, 84);
            this._overview.TabIndex = 2;
            // 
            // _topBar
            // 
            this._topBar.BackColor = System.Drawing.Color.FromArgb(22, 29, 46);
            this._topBar.Dock = System.Windows.Forms.DockStyle.Top;
            this._topBar.Name = "_topBar";
            this._topBar.Size = new System.Drawing.Size(1440, 60);
            this._topBar.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.FromArgb(13, 17, 28);
            this.ClientSize = new System.Drawing.Size(1440, 900);
            this.Controls.Add(this._centerPanel);
            this.Controls.Add(this._logPanel);
            this.Controls.Add(this._overview);
            this.Controls.Add(this._topBar);
            this.MinimumSize = new System.Drawing.Size(1140, 760);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Elevator Simulator - Dual Elevator Control Dashboard";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this._centerPanel.ResumeLayout(false);
            this._grid.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel _centerPanel;
        private System.Windows.Forms.TableLayoutPanel _grid;
        private ElevatorPanel _panelA;
        private ElevatorPanel _panelB;
        private LogView _logPanel;
        private OverviewView _overview;
        private TopBarView _topBar;
    }
}
